
# Calibration and validation datasets for soil organic carbon and root distributions
# from Pagliaro et al. 2026
# Sören Weber

# Bayesian analysis with brms

# calibration pits 2, 4, 5
# validations pits 1, 3

# scale
# DOM leaching from " calibration DOM leaching scaled by fine-roots "
# soilCscalars from " calibration total carbon curves prediction "

# packages ----

library( ggplot2 )
library( tidyr )
library( dplyr )
library( brms )
library( posterior )
library( cmdstanr )
library( patchwork )


# global settings ----

BRMS_BACKEND <- "cmdstanr"
BRMS_CHAINS <- 4
BRMS_CORES  <- 4          # one core per chain
BRMS_ITER   <- 4000
BRMS_WARMUP <- 1000
BRMS_SEED   <- 1

# Explicit rather than parallel::detectCores(), which counts logical cores
# and will oversubscribe a 4-physical-core machine.
options( mc.cores = BRMS_CORES )

# Fitted models are cached here as <name>.rds. brms appends the extension.
MODEL_DIR <- "models"
dir.create( MODEL_DIR , recursive = TRUE , showWarnings = FALSE )

# "on_change" reuses the cached fit unless data, formula or priors change.
# "never" forces reuse of whatever is on disk; "always" forces a refit.
BRMS_REFIT <- "on_change"


# functions ----

# root mean squared error function
rmse <- function( model , observed ) {
  sqrt( mean( ( model - observed ) ^ 2 ) )
}

# standard error function
std <- function(x) sd(x)/sqrt(length(x))

# depth in cm for predicting depth distributions
depth_cm <- 1:100
ln_depth_cm <- log( depth_cm )

# Beta likelihood needs values strictly inside (0, 1). No-op on interior
# data; only bites if a cumulative fraction is exactly 0 or 1.
squeeze01 <- function( y ) {
  n <- sum( is.finite( y ) )
  ( y * ( n - 1 ) + 0.5 ) / n
}

# Build a cache path from response, curve form, and dataset label, e.g.
#   models/cf_pom_logistic_val.rds
model_file <- function( resp , form , set ) {
  file.path( MODEL_DIR , paste( resp , form , set , sep = "_" ) )
}


# ---- priors -----------------------------------------------------------------
#
# mid is on the ln(depth) scale, so the inflection depth is D50 = exp(mid).
# Useful anchors:
#   mid 2.3 -> 10 cm    mid 2.7 -> 15 cm    mid 3.0 -> 20 cm
#   mid 3.4 -> 30 cm    mid 3.7 -> 40 cm    mid 3.9 -> 50 cm
#
# rate is the steepness of the rise in ln(depth) space. Values near 1 give a
# gradual profile; 2-3 gives a sharp transition. Bounded below at 0 so the
# curve cannot decrease with depth.
#
# The defaults below are weakly informative and centred on a ~20 cm
# inflection, which suits roots and bulk SOC. POM is shallower -- it is fed
# largely by aboveground litter, which enters at the surface and is
# fragmented in place rather than being distributed by roots -- so it gets
# its own shallower centre via PRIOR_MID$pom. See prior_mid_for() below.

PRIOR_RATE  <- "normal(1.4, 0.7)"
PRIOR_SD    <- "exponential(3)"
PRIOR_PHI   <- "gamma(2, 0.1)"
PRIOR_LBETA <- "normal(2.8, 1.2)"     # plogis(2.8) ~ 0.943

PRIOR_MID <- list(
  default = "normal(3.0, 1.0)" ,      # D50 ~ 20 cm, 90% mass 8-56 cm
  froot   = "normal(3.0, 1.0)" ,      # roots: ~20 cm
  tot_c   = "normal(3.2, 0.9)" ,      # bulk SOC: ~25 cm, slightly deeper
  maom    = "normal(3.3, 0.9)" ,      # MAOM: ~27 cm, deepest pool
  pom     = "normal(2.6, 0.8)"        # POM: ~13 cm, surface litter driven
)

# Pick the mid prior by matching the response name against PRIOR_MID.
prior_mid_for <- function( resp ) {
  hit <- names( PRIOR_MID )[ vapply( names( PRIOR_MID ) ,
                                     function( k ) grepl( k , resp , fixed = TRUE ) ,
                                     logical( 1 ) ) ]
  hit <- setdiff( hit , "default" )
  if ( length( hit ) == 0 ) return( PRIOR_MID$default )
  # longest match wins, so "tot_c" beats "c" if both were present
  PRIOR_MID[[ hit[ which.max( nchar( hit ) ) ] ]]
}


# logistic (Schenk & Jackson / log-depth)
logistic_curve_brms <- function( data , response ,
                                 set        = "cal" ,
                                 rate_prior = PRIOR_RATE ,
                                 mid_prior  = NULL ,
                                 sd_prior   = PRIOR_SD ,
                                 phi_prior  = PRIOR_PHI ,
                                 file       = NULL ,
                                 file_refit = BRMS_REFIT ,
                                 cores      = BRMS_CORES ,
                                 ... ) {

  resp <- deparse( substitute( response ) )
  data <- as.data.frame( data )

  stopifnot( resp %in% names( data ) ,
             all( c( "pit" , "depth_cm" , "ln_depth" ) %in% names( data ) ) )

  if ( is.null( mid_prior ) ) mid_prior <- prior_mid_for( resp )

  data[[ resp ]] <- squeeze01( data[[ resp ]] )

  bf_log <- bf(
    as.formula( paste0( resp , " ~ inv_logit(rate * (ln_depth - mid))" ) ) ,
    rate ~ 1 + (1 | pit) ,
    mid  ~ 1 + (1 | pit) ,
    nl = TRUE ,
    family = Beta( link = "identity" , link_phi = "log" )
  )

  # set_prior(), not prior(): prior() quotes its argument unevaluated and
  # would capture the symbol `rate_prior` rather than the string it holds.
  pr <- c(
    set_prior( rate_prior , nlpar = "rate" , lb = 0 ) ,
    set_prior( mid_prior  , nlpar = "mid" ) ,
    set_prior( sd_prior   , class = "sd" , nlpar = "rate" ) ,
    set_prior( sd_prior   , class = "sd" , nlpar = "mid" ) ,
    set_prior( phi_prior  , class = "phi" )
  )

  if ( is.null( file ) ) file <- model_file( resp , "logistic" , set )

  brm( bf_log , data = data , prior = pr ,
       chains     = BRMS_CHAINS ,
       cores      = cores ,
       backend    = BRMS_BACKEND ,
       iter       = BRMS_ITER ,
       warmup     = BRMS_WARMUP ,
       control    = list( adapt_delta = 0.99 , max_treedepth = 12 ) ,
       seed       = BRMS_SEED ,
       file       = file ,
       file_refit = file_refit ,
       ... )
}


# Gale & Grigal beta decay, sampled on logit scale
exp_decay_curve_brms <- function( data , response ,
                                  set         = "cal" ,
                                  lbeta_prior = PRIOR_LBETA ,
                                  sd_prior    = PRIOR_SD ,
                                  phi_prior   = PRIOR_PHI ,
                                  file        = NULL ,
                                  file_refit  = BRMS_REFIT ,
                                  cores       = BRMS_CORES ,
                                  ... ) {

  resp <- deparse( substitute( response ) )
  data <- as.data.frame( data )

  stopifnot( resp %in% names( data ) ,
             all( c( "pit" , "depth_cm" ) %in% names( data ) ) )

  data[[ resp ]] <- squeeze01( data[[ resp ]] )

  bf_gg <- bf(
    as.formula( paste0( resp , " ~ 1 - inv_logit(lbeta)^depth_cm" ) ) ,
    lbeta ~ 1 + (1 | pit) ,
    nl = TRUE ,
    family = Beta( link = "identity" , link_phi = "log" )
  )

  pr <- c(
    set_prior( lbeta_prior , nlpar = "lbeta" ) ,
    set_prior( sd_prior    , class = "sd" , nlpar = "lbeta" ) ,
    set_prior( phi_prior   , class = "phi" )
  )

  if ( is.null( file ) ) file <- model_file( resp , "beta" , set )

  brm( bf_gg , data = data , prior = pr ,
       chains     = BRMS_CHAINS ,
       cores      = cores ,
       backend    = BRMS_BACKEND ,
       iter       = BRMS_ITER ,
       warmup     = BRMS_WARMUP ,
       control    = list( adapt_delta = 0.99 , max_treedepth = 12 ) ,
       seed       = BRMS_SEED ,
       file       = file ,
       file_refit = file_refit ,
       ... )
}


curve_band_brms <- function(fit, depth_grid = 1:100, level = 0.89) {
  nd <- data.frame(depth_cm = depth_grid, ln_depth = log(depth_grid), pit = NA)

  ep <- posterior_epred(fit, newdata = nd,
                        re_formula = NA, allow_new_levels = TRUE)

  a <- (1 - level) / 2
  data.frame(
    depth_cm = depth_grid,
    fit  = colMeans(ep),
    se   = apply(ep, 2, sd),
    lwr  = apply(ep, 2, quantile, a),
    upr  = apply(ep, 2, quantile, 1 - a)
  )
}

curve_eval_brms <- function(data, response, fit_l, fit_e,
                            depth_grid = 1:100, digits = 2) {
  resp <- deparse(substitute(response))
  data <- as.data.frame(data)

  band_l <- curve_band_brms(fit_l, depth_grid)
  band_e <- curve_band_brms(fit_e, depth_grid)

  nd <- data.frame(depth_cm = data$depth_cm,
                   ln_depth = log(data$depth_cm), pit = NA)
  pred_l <- colMeans(posterior_epred(fit_l, newdata = nd,
                                     re_formula = NA, allow_new_levels = TRUE))
  pred_e <- colMeans(posterior_epred(fit_e, newdata = nd,
                                     re_formula = NA, allow_new_levels = TRUE))

  obs <- data[[resp]]
  stat <- function(p) {
    r <- obs - p
    c(r2   = round(1 - sum(r^2) / sum((obs - mean(obs))^2), digits),
      rmse = round(sqrt(mean(r^2)), digits),
      bias = round(mean(r), digits))
  }

  pars <- list(
    rate = unname( fixef(fit_l)["rate_Intercept", "Estimate"] ),
    mid  = unname( fixef(fit_l)["mid_Intercept",  "Estimate"] ),
    d50  = exp( unname( fixef(fit_l)["mid_Intercept", "Estimate"] ) ),
    beta = plogis( unname( fixef(fit_e)["lbeta_Intercept", "Estimate"] ) )
  )

  list(pars = pars,
       curves = data.frame(depth_cm = depth_grid,
                           logistic = band_l$fit, beta = band_e$fit),
       bands  = list(logistic = band_l, beta = band_e),
       stats  = rbind(logistic = stat(pred_l), beta = stat(pred_e)))
}

curves_plot <- function(band_e, band_l, response, data,
                        r2_e, rmse_e, r2_l, rmse_l, alpha = 0.2) {
  ggplot(band_e, aes(depth_cm, fit)) +
    # geom_ribbon(aes(ymin = lwr, ymax = upr), fill = "blue",
    #             alpha = alpha, colour = NA) +
    geom_ribbon(data = band_l, aes(ymin = lwr, ymax = upr), fill = "red",
                alpha = alpha, colour = NA) +
    # geom_line(linewidth = 1, colour = "blue") +
    geom_line(data = band_l, linewidth = 1, colour = "red") +
    geom_line(data = data, aes(depth_cm, {{ response }},
                               colour = as.factor(pit))) +
    geom_point(data = data, aes(depth_cm, {{ response }},
                                colour = as.factor(pit))) +
    # annotate("text", colour = "blue", x = 80, y = 0.3,
    #          label = paste0("neg. exponential\nR^2 = ", r2_e,
    #                         "\nRMSE = ", rmse_e)) +
    annotate("text", colour = "red", x = 35, y = 0.3,
             label = paste0("logistic\nR\u00b2 = ", r2_l,
                            "\nRMSE = ", rmse_l)) +
    scale_x_reverse(limits = c(100, 0), expand = c(0, 0) ,
    breaks = c( 0 , 30 ,50 , 70 , 100 )
  ) +
    coord_flip(expand = FALSE, ylim = c(0, 1)) +
    theme_bw() +
    theme(aspect.ratio = 1, legend.position = "none")
}

# layer fractions from a fitted logistic, for FBC
layer_fracs <- function( rate , mid , edges = c(0, 30, 50, 70, 100) ) {
  cum <- 1 / ( 1 + exp( -rate * ( log( edges[-1] ) - mid ) ) )
  out <- diff( c( 0 , cum ) )
  names( out ) <- paste0( head( edges , -1 ) , "_" , edges[-1] )
  out
}


# load data ----

setwd( "~/Dropbox/WVU_postdoc/projects/weber_deep_fbc/calibration_validation/")
dir.create( MODEL_DIR , recursive = TRUE , showWarnings = FALSE )

dtf <-
  read.csv( "Pagliaro_DeepSoils_Data.csv") %>%
  select( sampleID , pit , depth , froot_g_cm3soil , vol_cm3 , Tot_C_g , MAOM_C_g , POM_C_g  )

# data preparation ----

# getting MAOM, POM, Total C (sum of MAOM and POM for mass conservation) and fine root biomass in a kg per m2 basis

dtf <-
  dtf %>%
  mutate(
    POM_C_g_cm3 = POM_C_g / vol_cm3 ,
    MAOM_C_g_cm3 = MAOM_C_g / vol_cm3 ,
    Tot_C_g_cm3 = MAOM_C_g_cm3 + POM_C_g_cm3 ,

    height_cm = case_when(
      depth == "0 to 15" ~ 15 ,
      depth == "15 to 30" ~ 15 ,
      depth == "30 to 50" ~ 20 ,
      depth == "50 to 70" ~ 20 ,
      depth == "70 to 100" ~ 30 ) ,

    depth_cm = case_when(
      depth == "0 to 15" ~ 15 ,
      depth == "15 to 30" ~ 30 ,
      depth == "30 to 50" ~ 50 ,
      depth == "50 to 70" ~ 70 ,
      depth == "70 to 100" ~ 100 ) ,

    depth = case_when(
      depth == "0 to 15" ~ 30 ,
      depth == "15 to 30" ~ 30 ,
      depth == "30 to 50" ~ 50 ,
      depth == "50 to 70" ~ 70 ,
      depth == "70 to 100" ~ 100 ) ,

    # g C per cm3 to cm2
    Tot_C_g_cm2 = Tot_C_g_cm3 * height_cm ,
    POM_C_g_cm2 = POM_C_g_cm3 * height_cm ,
    MAOM_C_g_cm2 = MAOM_C_g_cm3 * height_cm ,

    # g froot per cm3 to cm2
    froot_g_cm2 = froot_g_cm3soil * height_cm ,

    # g C per cm2 to m2
    Tot_C_g_m2  = Tot_C_g_cm2 * 1e4 ,
    POM_C_g_m2 =  POM_C_g_cm2 * 1e4 ,
    MAOM_C_g_m2 = MAOM_C_g_cm2 *  1e4 ,

    # g froot  per cm2 to m2
    froot_g_m2 = froot_g_cm2 *  1e4 ,

    # g C per m2 to kg C per m2
    Tot_C_kg_m2  = Tot_C_g_m2 * 1e-3 ,
    POM_C_kg_m2 =  POM_C_g_m2 * 1e-3 ,
    MAOM_C_kg_m2 = MAOM_C_g_m2 * 1e-3 ,

    # g froot  per cm2 to m2
    froot_kg_m2 = froot_g_m2 *  1e-3 ) |>
  rename_all( tolower )

# 13.6 kg C m^2 is mean total soil carbon  from 0-100 in Pagliaro et al. 2026
# mean(
# dtf |> 
#   group_by( pit ) |> 
#   reframe( tot_c_kg_m2 = sum( tot_c_kg_m2 ) ) |> 
#   pull( tot_c_kg_m2 ) ) 


dtf <-
  dtf  |>
  select( pit , depth_cm , tot_c_kg_m2 , froot_kg_m2 , maom_c_kg_m2 , pom_c_kg_m2 )

# depth distributions of total soil organic carbon and fine-roots

sums <-
  dtf |>
  group_by( pit ) |>
  reframe(
    sum_tot_c_kg_m2 = sum( tot_c_kg_m2 ) ,
    sum_froot_kg_m2 = sum( froot_kg_m2 ) ,
    sum_maom_c_kg_m2 = sum( maom_c_kg_m2 ) ,
    sum_pom_c_kg_m2 = sum( pom_c_kg_m2 ) ,
  )

mean( sums$sum_tot_c_kg_m2 )
std( sums$sum_tot_c_kg_m2 )

mean( sums$sum_froot_kg_m2 )
std( sums$sum_froot_kg_m2 )

dtf_cf <-
  dtf %>%
  left_join( sums , by = "pit" ) %>%
  group_by( pit ) %>%
  arrange( depth_cm , .by_group = TRUE ) %>%
  mutate(
    tot_c_frac = tot_c_kg_m2 / sum_tot_c_kg_m2 ,
    froot_frac = froot_kg_m2 / sum_froot_kg_m2 ,

    # change to
    # maom pom
    maom_c_frac = maom_c_kg_m2 / sum_maom_c_kg_m2 ,
    pom_c_frac = pom_c_kg_m2 / sum_pom_c_kg_m2 ,

    cf_tot_c = cumsum( tot_c_frac ) ,
    cf_froot = cumsum( froot_frac )  ,
    cf_maom = cumsum( maom_c_frac )  ,
    cf_pom = cumsum( pom_c_frac )
  ) %>%
  ungroup() %>%
  select( pit , depth_cm , cf_tot_c , cf_froot , cf_maom , cf_pom )

# before fitting models
# log transforming depth
# and removing the lowest depths because they definitionally have 100% cumulative sums of fractions

dtf_cf <-
  dtf_cf |>
  filter( depth_cm != 100 ) |>
  mutate( ln_depth = log( depth_cm ) ) |>
  as.data.frame()

# calibration dataset ----

dtfc <-
  dtf_cf |>
  filter( pit ==  2 | pit == 4 | pit == 5 )

# validation dataset ----

dtfv <-
  dtf_cf |>
  filter( pit ==  1 | pit ==  3  )

# calibration fine-roots curves -----
# # # # # # # # # # # # # # # # #
# fine-roots depth distribution #
# # # # # # # # # # # # # # # # #

# -> models/cf_froot_logistic_cal.rds , models/cf_froot_beta_cal.rds
fit_froots_l_c <- logistic_curve_brms(  dtfc , cf_froot , set = "cal" )
fit_froots_e_c <- exp_decay_curve_brms( dtfc , cf_froot , set = "cal" )

res_froots_c <- curve_eval_brms(dtfc, cf_froot, fit_froots_l_c, fit_froots_e_c)
res_froots_c$stats
res_froots_c$pars

froot_cal_plot <- 
curves_plot(res_froots_c$bands$beta, res_froots_c$bands$logistic,
            cf_froot, dtfc,
            r2_e = res_froots_c$stats["beta", "r2"],
            rmse_e = res_froots_c$stats["beta", "rmse"],
            r2_l = res_froots_c$stats["logistic", "r2"],
            rmse_l = res_froots_c$stats["logistic", "rmse"]) +
  ylab(expression("Fraction of roots" ~ m^-2)) +
  xlab("Depth (cm)") +
  ggtitle("Fine-root depth distribution\nCALIBRATION (pits 2,4,5)") +
  annotate("text", colour = "red", x = 75, y = 0.3,
             label = paste0(" Rate = ", round( exp(res_froots_c$pars$rate) , digits = 2 ),
                            "\nMidpoint = ", round( exp(res_froots_c$pars$mid) , digits = 2)))

# for FBC: pooled parameters
froots_l_c_rate <- res_froots_c$pars$rate
froots_l_c_mid  <- res_froots_c$pars$mid

write.csv( 
  data.frame( 
    root_fraction_rate = froots_l_c_rate ,
    root_fraction_midpoint = froots_l_c_mid
    ) ,
  "root_fraction_logistic_parameters.csv" ,
  row.names = FALSE
  )


cf_froots_l_c <-   1 / ( 1 + exp( -froots_l_c_rate * ( ln_depth_cm - froots_l_c_mid ) ) )

# calibration fine-roots prediction -----

# logistic better

# fraction of roots
# 0_30  30_50  50_70 70_100 
# 0.77   0.08   0.04   0.03 
round( layer_fracs( froots_l_c_rate , froots_l_c_mid ) , digits = 3 )
round( layer_fracs( froots_l_c_rate , froots_l_c_mid ) , digits = 3 ) /0.775


# calibration DOM leaching scaled by fine-roots ----

# DOM leaching for whole soil profile from 
# Hussain, M. Z., G. P. Robertson, B. Basso, and S. K. Hamilton. 2020. Leaching losses of dissolved organic carbon and nitrogen from agricultural soils in the upper US Midwest. The Science of the Total Environment 734:139379.
# In text, 18.1 ± 6.3 kg ha^-1 yr^-1 for miscanthus. 
# The high end is therefore -> 0.00244 kg m^-2 yr^-1

# 13.6 kg C m^-2 total soil carbon from Pagliaro et al. 2026
  # see calculation above under data preparation

# if we calculate the proportion
#   (0.00244 kg m^-2 yr^-1) / (15.21 kg m^-2 ) = 0.000160421
# ** THIS 15.21 IS FROM ZOE'S TOTAL C THROUGHOUT THE SOIL PROFILE
# 
# The percentage of C lost per year from the whole soil profile is therefore 0.015 %

# assuming that carbon leaching is proportional to roots
# so that these amounts are higher in shallow soils with many roots

DOMleach <- 
(0.000160421 * round( layer_fracs( froots_l_c_rate , froots_l_c_mid ) , digits = 2 )/
  round( layer_fracs( froots_l_c_rate , froots_l_c_mid ) , digits = 2 )[4]) 

DOMleach <- 
as.data.frame( DOMleach) 

DOMleach$depth_cm <- rownames( DOMleach)
write.csv( DOMleach , "DOMleach.csv" , row.names = FALSE )

# calibration total carbon curves -----

# -> models/cf_tot_c_logistic_cal.rds , models/cf_tot_c_beta_cal.rds
fit_tot_c_l_c <- logistic_curve_brms(  dtfc , cf_tot_c , set = "cal" )
fit_tot_c_e_c <- exp_decay_curve_brms( dtfc , cf_tot_c , set = "cal" )

res_tot_c_c <- curve_eval_brms(dtfc, cf_tot_c, fit_tot_c_l_c, fit_tot_c_e_c)
res_tot_c_c$stats
res_tot_c_c$pars

tot_c_cal_plot <- 
curves_plot(res_tot_c_c$bands$beta, res_tot_c_c$bands$logistic,
            cf_tot_c, dtfc,
            r2_e = res_tot_c_c$stats["beta", "r2"],
            rmse_e = res_tot_c_c$stats["beta", "rmse"],
            r2_l = res_tot_c_c$stats["logistic", "r2"],
            rmse_l = res_tot_c_c$stats["logistic", "rmse"]) +
  ylab(expression("Fraction of Total C" ~ m^-2)) +
  xlab("Depth (cm)") +
  ggtitle("Total C depth distribution\nCALIBRATION (pits 2,4,5)") +
  annotate("text", colour = "red", x = 75, y = 0.3,
             label = paste0(" Rate = ", round( exp(res_tot_c_c$pars$rate) , digits = 2 ),
                            "\nMidpoint = ", round( exp(res_tot_c_c$pars$mid) , digits = 2)))


# for FBC: pooled parameters
tot_c_l_c_rate <- res_tot_c_c$pars$rate
tot_c_l_c_mid  <- res_tot_c_c$pars$mid

cf_tot_c_l_c <-   1 / ( 1 + exp( -tot_c_l_c_rate * ( ln_depth_cm - tot_c_l_c_mid ) ) )

# calibration total carbon curves prediction -----

# logistic better

# fraction of soil carbon
# 0-30  30-50   50-70   70-100
# 0.54  0.23    0.10    0.06
soc_layers <- layer_fracs( tot_c_l_c_rate , tot_c_l_c_mid )
round( soc_layers , digits = 2 )

soc_30  <- soc_layers[["0_30"]]
soc_50  <- soc_layers[["30_50"]]
soc_70  <- soc_layers[["50_70"]]
soc_100 <- soc_layers[["70_100"]]

# soil carbon scalars from pits 2, 4, 5
soc_scalar_50 <- soc_50 / soc_30   # 0.40
soc_scalar_70 <- soc_70 / soc_30   # 0.19
soc_scalar_100 <- soc_100 / soc_30  # 0.13

write.csv( cbind( soc_scalar_50 , soc_scalar_70 , soc_scalar_100 ) ,
           "soc_scalars.csv" , row.names = FALSE )

# validation total carbon curves ----

# Step 1
# Get the cumulative fraction curve as before
# Step 2
# Estimate the mean and se of total carbon throughout the depth profile of the validation pits
# Step 3
# Propagate the error in the mean amount of total carbon throughout the depth profile 
# Step 4 
# Summarize to get the total amount of carbon at each portion of the depth profile

# -> models/cf_tot_c_logistic_val.rds , models/cf_tot_c_beta_val.rds
fit_tot_c_l_v <- logistic_curve_brms(  dtfv , cf_tot_c , set = "val" )
fit_tot_c_e_v <- exp_decay_curve_brms( dtfv , cf_tot_c , set = "val" )

res_tot_c_v <- curve_eval_brms(dtfv, cf_tot_c, fit_tot_c_l_v, fit_tot_c_e_v)
res_tot_c_v$stats
res_tot_c_v$pars
res_tot_c_v$bands$logistic
# predictions of soil carbon throughout the depth profile


tot_c_val_plot <- 
curves_plot(res_tot_c_v$bands$beta, res_tot_c_v$bands$logistic,
            cf_tot_c, dtfv,
            r2_e = res_tot_c_v$stats["beta", "r2"],
            rmse_e = res_tot_c_v$stats["beta", "rmse"],
            r2_l = res_tot_c_v$stats["logistic", "r2"],
            rmse_l = res_tot_c_v$stats["logistic", "rmse"]) +
  ylab(expression("Fraction of Total C" ~ m^-2)) +
  xlab("Depth (cm)") +
  ggtitle("Total C depth distribution\nVALIDATION (pits 1,3)")+
  annotate("text", colour = "red", x = 75, y = 0.3,
             label = paste0(" Rate = ", round( exp(res_tot_c_v$pars$rate) , digits = 2 ),
                            "\nMidpoint = ", round( exp(res_tot_c_v$pars$mid) , digits = 2)))

# estimating this in total amounts for each depth layer, 
# rather than cumulative fraction

# total c in kg per m2
dtot <- sums |> filter(pit %in% c(1, 3))
sum_tot_c_kg_m2 <- mean( dtot$sum_tot_c_kg_m2)
sum_tot_c_kg_m2_se <- std( dtot$sum_tot_c_kg_m2)

# draws from our model 
draws_tot_c_l <- as_draws_df(fit_tot_c_l_v)

# per-draw layer fractions from the logistic
cum_at <- function(d, rate, mid) 1 / (1 + exp(-rate * (log(d) - mid)))

edges <- c(0, 30, 50, 70, 100)
cum_draws_tot_c_l <- sapply(edges[-1], function(d)
  cum_at(d, draws_tot_c_l$b_rate_Intercept, draws_tot_c_l$b_mid_Intercept))

frac_draws_tot_c_l <- cbind(cum_draws_tot_c_l[,1], t(apply(cum_draws_tot_c_l, 1, diff)))
colnames(frac_draws_tot_c_l) <- c("0_30", "30_50", "50_70", "70_100")

# propagate uncertainty by drawing a normal distribution from
# the mean and se of the pit total data
# this is multiplicative error propagation. 
n <- nrow(frac_draws_tot_c_l)
total_draws <- rnorm(n, mean = sum_tot_c_kg_m2, sd = sum_tot_c_kg_m2_se)

tot_c_stock_draws <- frac_draws_tot_c_l * total_draws   # recycles total_draws across columns

stock_summary <- data.frame(
  layer = colnames(tot_c_stock_draws),
  tot_c_kg_m2  = colMeans(tot_c_stock_draws),
  tot_c_kg_m2_se    = apply(tot_c_stock_draws, 2, sd),
  tot_c_kg_m2_lwr   = apply(tot_c_stock_draws, 2, quantile, 0.16),
  tot_c_kg_m2_upr   = apply(tot_c_stock_draws, 2, quantile, 0.84)
)



# validation maom_c dd ----

# Step 1
# Get the cumulative fraction curve as before
# Step 2
# Estimate the mean and se of maom carbon throughout the depth profile of the validation pits
# Step 3
# Propagate the error in the mean amount of maom carbon throughout the depth profile 
# Step 4 
# Summarize to get the amount of maom carbon at each portion of the depth profile

# -> models/cf_maom_logistic_val.rds , models/cf_maom_beta_val.rds
fit_maom_c_l_v <- logistic_curve_brms(  dtfv , cf_maom , set = "val" )
fit_maom_c_e_v <- exp_decay_curve_brms( dtfv , cf_maom , set = "val" )

res_maom_v <- curve_eval_brms(dtfv, cf_maom, fit_maom_c_l_v, fit_maom_c_e_v)
res_maom_v$stats
res_maom_v$pars
res_maom_v$bands$logistic

# predictions of soil carbon throughout the depth profile

maom_c_val_plot <- 
curves_plot(res_maom_v$bands$beta, res_maom_v$bands$logistic,
            cf_maom, dtfv,
            r2_e = res_maom_v$stats["beta", "r2"],
            rmse_e = res_maom_v$stats["beta", "rmse"],
            r2_l = res_maom_v$stats["logistic", "r2"],
            rmse_l = res_maom_v$stats["logistic", "rmse"]) +
  ylab(expression("Fraction of MAOM C" ~ m^-2)) +
  xlab("Depth (cm)") +
  ggtitle("MAOM C depth distribution\nVALIDATION (pits 1,3)") +
  annotate("text", colour = "red", x = 75, y = 0.3,
             label = paste0(" Rate = ", round( exp(res_maom_v$pars$rate) , digits = 2 ),
                            "\nMidpoint = ", round( exp(res_maom_v$pars$mid) , digits = 2)))

# maom c in kg per m2
sum_maom_c_kg_m2 <- mean( dtot$sum_maom_c_kg_m2)
sum_maom_c_kg_m2_se <- std( dtot$sum_maom_c_kg_m2)

draws_maom_c_l <- as_draws_df(  fit_maom_c_l_v )

# per-draw layer fractions from the logistic
cum_draws_maom_c_l <- sapply(edges[-1], function(d)
  cum_at(d, draws_maom_c_l$b_rate_Intercept, draws_maom_c_l$b_mid_Intercept))

frac_draws_maom_c_l <- cbind(cum_draws_maom_c_l[,1], t(apply(cum_draws_maom_c_l, 1, diff)))
colnames(frac_draws_maom_c_l) <- c("0_30", "30_50", "50_70", "70_100")

n <- length( frac_draws_maom_c_l )
maom_draws <- rnorm(n, mean = sum_maom_c_kg_m2, sd = sum_maom_c_kg_m2_se)

maom_stock_draws <- frac_draws_maom_c_l * maom_draws   # recycles maom_draws across columns

stock_summary <- 
  stock_summary |> 
    left_join( 
    data.frame(
    layer = colnames(maom_stock_draws),
    maom_c_kg_m2  = colMeans(maom_stock_draws),
    maom_c_kg_m2_se    = apply(maom_stock_draws, 2, sd),
    maom_c_kg_m2_lwr   = apply(maom_stock_draws, 2, quantile, 0.16),
    maom_c_kg_m2_upr   = apply(maom_stock_draws, 2, quantile, 0.84)
    )
  )

# validation pom_c dd ----

# Step 1
# Get the cumulative fraction curve as before
# Step 2
# Estimate the mean and se of pom carbon throughout the depth profile of the validation pits
# Step 3
# Propagate the error in the mean amount of pom carbon throughout the depth profile 
# Step 4 
# Summarize to get the amount of pom carbon at each portion of the depth profile

# -> models/cf_pom_logistic_val.rds , models/cf_pom_beta_val.rds
fit_pom_c_l_v <- logistic_curve_brms(  dtfv , cf_pom , set = "val" )
fit_pom_c_e_v <- exp_decay_curve_brms( dtfv , cf_pom , set = "val" )

res_pom_v <- curve_eval_brms(dtfv, cf_pom, fit_pom_c_l_v, fit_pom_c_e_v)

res_pom_v$stats
res_pom_v$pars
res_pom_v$bands$logistic

# predictions of soil carbon throughout the depth profile


pom_c_val_plot <- 
curves_plot(res_pom_v$bands$beta, res_pom_v$bands$logistic,
            cf_pom, dtfv,
            r2_e = res_pom_v$stats["beta", "r2"],
            rmse_e = res_pom_v$stats["beta", "rmse"],
            r2_l = res_pom_v$stats["logistic", "r2"],
            rmse_l = res_pom_v$stats["logistic", "rmse"]) +
  ylab(expression("Fraction of POM C" ~ m^-2)) +
  xlab("Depth (cm)") +
  ggtitle("POM C depth distribution\nVALIDATION (pits 1,3)") +
  annotate("text", colour = "red", x = 75, y = 0.3,
             label = paste0(" Rate = ", round( exp(res_pom_v$pars$rate) , digits = 2 ),
                            "\nMidpoint = ", round( exp(res_pom_v$pars$mid) , digits = 2)))

# pom c in kg per m2
sum_pom_c_kg_m2 <- mean( dtot$sum_pom_c_kg_m2)
sum_pom_c_kg_m2_se <- std( dtot$sum_pom_c_kg_m2)

draws_pom_l <- as_draws_df(  fit_pom_c_l_v )

# per-draw layer fractions from the logistic
cum_draws_pom_l <- sapply(edges[-1], function(d)
  cum_at(d, draws_pom_l$b_rate_Intercept, draws_pom_l$b_mid_Intercept))

frac_draws_pom_l <- cbind(cum_draws_pom_l[,1], t(apply(cum_draws_pom_l, 1, diff)))
colnames(frac_draws_pom_l) <- c("0_30", "30_50", "50_70", "70_100")

n <- length( frac_draws_pom_l )
pom_draws <- rnorm(n, mean = sum_pom_c_kg_m2, sd = sum_pom_c_kg_m2_se)

pom_stock_draws <- frac_draws_pom_l * pom_draws   # recycles pom_draws across columns


stock_summary <- 
  stock_summary |> 
  left_join( 
    data.frame(
      layer = colnames(pom_stock_draws),
      pom_c_kg_m2  = colMeans(pom_stock_draws),
      pom_c_kg_m2_se    = apply(pom_stock_draws, 2, sd),
      pom_c_kg_m2_lwr   = apply(pom_stock_draws, 2, quantile, 0.16),
      pom_c_kg_m2_upr   = apply(pom_stock_draws, 2, quantile, 0.84) 
    )
  )

# can get maom to pom ratio with these draws with the error fully propapagated!! 
maom_pom_draws <- maom_stock_draws / pom_stock_draws

stock_summary <- 
stock_summary |> 
  left_join( 
    data.frame(
      layer = colnames(maom_pom_draws),
      maom_pom = colMeans(maom_pom_draws),
      maom_pom_se    = apply(maom_pom_draws, 2, sd),
      maom_pom_lwr   = apply(maom_pom_draws, 2, quantile, 0.16),
      maom_pom_upr   = apply(maom_pom_draws, 2, quantile, 0.84) 
    ) )



write.csv( stock_summary , "validation_dataset.csv" , row.names = FALSE )

# printing plots ----

cal_val_plot <- 
( froot_cal_plot + tot_c_cal_plot) / 
  (tot_c_val_plot + maom_c_val_plot + pom_c_val_plot ) +
  plot_annotation(tag_levels = "A")

png("cal_val_plot.png",
    width = 10, height = 6, units = 'in', res = 450) 
print( cal_val_plot ) 
dev.off()

# total soil carbon ------


mean( 
dtf |> 
  group_by( pit ) |> 
  reframe( tot_sum = sum( tot_c_kg_m2 ) )
)
