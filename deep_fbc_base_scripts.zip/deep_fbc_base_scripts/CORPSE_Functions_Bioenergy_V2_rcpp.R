# =============================================================================
# CORPSE functions -- Rcpp version
# 2026-08-21 SW
#
# Drop-in replacement for CORPSE_Functions_Bioenergy_V2_matrix_fast.R. The
# arithmetic runs in C++ (corpse_kernel.cpp); everything else is unchanged.
#
# WHAT THE DRIVER SCRIPT HAS TO DO
#   1. source() this file instead of the _fast one
#   2. keep calling prep_corpse_params() on each params object, exactly as in
#      the _fast version -- it now builds the flat vector the kernel needs
#   No CORPSE() call site changes. Signature and return type are identical:
#   matrix in -> matrix out with column names; data.frame in -> data.frame out.
#
# WHAT TO EXPECT NUMERICALLY
#   NOT bit-identical to the R version. C++ evaluates in a different order and
#   may fuse multiply-add, so expect agreement to ~1e-14 relative. That is
#   reordered floating point, not a logic difference. If you need an exactly
#   reproducible demonstration, use the _fast R version instead.
#
# REQUIREMENTS
#   install.packages("Rcpp")            # and a compiler:
#   sudo apt install r-base-dev build-essential      (Ubuntu)
#   corpse_kernel.cpp must sit in the same directory as this file.
# =============================================================================

library( Rcpp )

# ---- locate and compile the kernel ------------------------------------------
# Rcpp::sourceCpp() recompiles on every session (a few seconds). cacheDir keeps
# the compiled object so repeated runs -- and parallel workers in a sensitivity
# analysis -- skip the compile.
.corpse_cpp_dir <- tryCatch({
  a <- commandArgs( trailingOnly = FALSE )
  f <- sub( "^--file=" , "" , a[ grep( "^--file=" , a ) ] )
  if ( length(f) ) dirname( normalizePath( f ) ) else getwd()
}, error = function(e) getwd() )

.corpse_kernel_path <- file.path( .corpse_cpp_dir , "fbc_rcpp_testing/corpse_kernel.cpp" )
if ( !file.exists( .corpse_kernel_path ) ) {
  # fall back to the directory this file was sourced from
  .corpse_kernel_path <- "fbc_rcpp_testing/corpse_kernel.cpp"
}

.corpse_cache <- file.path( tempdir() , "corpse_rcpp_cache" )
dir.create( .corpse_cache , showWarnings = FALSE , recursive = TRUE )
Rcpp::sourceCpp( .corpse_kernel_path , cacheDir = .corpse_cache )

# ---- shared definitions (unchanged from the R version) ----------------------
chem_types <- c('Fast','Slow','Necro')

uC_names <- paste0('u', chem_types, 'C')
uN_names <- paste0('u', chem_types, 'N')
pC_names <- paste0('p', chem_types, 'C')
pN_names <- paste0('p', chem_types, 'N')
Vmaxref_names <- paste0('Vmaxref_', chem_types)
Ea_names      <- paste0('Ea_', chem_types)
kC_names      <- paste0('kC_', chem_types)
eup_names     <- paste0('eup_', chem_types)
nup_names     <- paste0('nup_', chem_types)
prot_names    <- paste0('protection_rate_', chem_types)

pool_column_names <- c("uFastC","uSlowC","uNecroC",
                       "pFastC","pSlowC","pNecroC",
                       "livingMicrobeC",
                       "uFastN","uSlowN","uNecroN",
                       "pFastN","pSlowN","pNecroN",
                       "inorganicN","CO2","livingMicrobeN")

prot_clay <- function (claypercent, slope=0.4833, intercept=2.3282, BD=1.15, porosity=0.4) {
  1.0*(10**(slope*log10(claypercent)+intercept)*BD*1e-6)
}

# ---- parameter preparation --------------------------------------------------
# Same name and same role as in the _fast R version, so driver scripts do not
# change. Here it builds the FLAT vector the C++ kernel indexes positionally.
# The layout is fixed and must match the header of corpse_kernel.cpp.
prep_corpse_params <- function( params ) {
  flat <- as.numeric( c(
    unlist( params[ Vmaxref_names ] , use.names = FALSE ),   #  0- 2
    unlist( params[ Ea_names ]      , use.names = FALSE ),   #  3- 5
    unlist( params[ kC_names ]      , use.names = FALSE ),   #  6- 8
    unlist( params[ eup_names ]     , use.names = FALSE ),   #  9-11
    unlist( params[ nup_names ]     , use.names = FALSE ),   # 12-14
    unlist( params[ prot_names ]    , use.names = FALSE ),   # 15-17
    params$gas_diffusion_exp,                                # 18
    params$minMicrobeC,                                      # 19
    params$Tmic,                                             # 20
    params$et,                                               # 21
    params$tProtected,                                       # 22
    params$frac_N_turnover_min,                              # 23
    params$CN_Microbe,                                       # 24
    params$max_immobilization_rate,                          # 25
    params$substrate_diffusion_exp,                          # 26
    params$frac_turnover_slow,                               # 27
    as.numeric( isTRUE( params$new_resp_units ) ) ) )         # 28
  if ( length( flat ) != 29L || any( !is.finite( flat ) ) ) {
    stop( "prep_corpse_params: expected 29 finite values, got ",
          length( flat ), call. = FALSE )
  }
  attr( params , "corpse_flat" ) <- flat
  params
}

.corpse_flat <- function( params ) {
  f <- attr( params , "corpse_flat" , exact = TRUE )
  if ( is.null( f ) ) f <- attr( prep_corpse_params( params ) , "corpse_flat" , exact = TRUE )
  f
}

# ---- column order guard -----------------------------------------------------
# The kernel indexes columns positionally, so a reordered pool object would
# produce silently wrong answers rather than an error. Checked on every call;
# the cost is negligible next to the arithmetic.
.corpse_check_cols <- function( nm ) {
  if ( is.null( nm ) || !identical( nm , pool_column_names ) ) {
    stop( "CORPSE (Rcpp): pool columns are not in the expected order.\n",
          "  expected: ", paste( pool_column_names , collapse = ", " ), "\n",
          "  got     : ", paste( nm , collapse = ", " ), call. = FALSE )
  }
}

# ---- CORPSE -----------------------------------------------------------------
# Identical signature to the R version.
CORPSE <- function( SOM , T , theta , params , claymod = 1.0 , Litter = FALSE ) {

  was_df <- is.data.frame( SOM )
  X <- if ( was_df ) as.matrix( SOM ) else SOM
  .corpse_check_cols( colnames( X ) )

  derivs <- corpse_deriv_cpp( X , T , theta , .corpse_flat( params ) ,
                              claymod , isTRUE( Litter ) )

  dimnames( derivs ) <- list( NULL , pool_column_names )
  if ( was_df ) derivs <- as.data.frame( derivs )
  derivs
}
