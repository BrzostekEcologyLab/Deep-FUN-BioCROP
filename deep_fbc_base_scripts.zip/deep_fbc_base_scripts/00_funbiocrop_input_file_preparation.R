# *****Script to generate input file for 1500 year prairie spin up*****
#   
# This code creates a data table of daily values used to run the FUN-BioCROP model 
# with LIDET parameters. It merges DayCent C and N data with the schedule and 
# details of bioenergy events (planting, cultivation, harvest, last growing day, 
# fertilization). It then calculates turnover and the rhizosphere fraction, and 
# fills in crop-specific values of leaf and root litter fastfracs and root diameters.


rm(list=ls(all=TRUE)) 


library(dplyr) # left_join


# Set working directory
setwd("~/Dropbox/WVU_postdoc/projects/weber_deep_fbc/00_spinup/input_file_preparation/")

# load data
daycent_bio <- read.csv("spin_bio.csv", header = TRUE) # daycent output is in g/m2, CORPSE needs kg C/m2 (converted below)
daycent_npp <- read.csv("spin_npp.csv", header = TRUE)
evtdet <- read.csv("events_details.csv", header = TRUE)
evtdum <- read.csv("events_dummy.csv", header = TRUE)




# r Prepare Input File --------------

input <- left_join(daycent_npp, daycent_bio, by = c("time", "dayofyr"))

#change column names 
colnames(input)[colnames(input) == "dayofyr"] <- "doy"
colnames(input)[colnames(input) == "time"] <- "yr"

# remove leap years
input <- input[which(input$doy != 366),]

# convert g to kg (Daycent is in g/m2, CORPSE is in kg/m2)
input[,c(3:10)] <- input[,c(3:10)]/1000  

# remove decimal points in "yr" column
input$yr <- trunc(input$yr)
# set the years to end at 1846, last year before our modern spin up starts in 1847. This spin up yr goes from 2500 to 4000
input$yr <- input$yr - 2154

# create year number (nyr) for input data
input$nyr <- input$yr - 345

# add columns with zeros for agricultural events and details not used in spinup
input$omad <- 0
input$crop <- 0
input$cult <- 0
input$harv <- 0
input$last <- 0 # we need values for FUN to work (added below)
input$fert <- 0
input$croptype <- 0
input$cropsrl <-  76.58*100*10 # value for TMC4 (big bluestem, indiangrass, little bluestem), average of FRED data for 3 species 
input$cultrhizmix <- 0
input$cultlitmix <- 0
input$harvremov <- 0
input$omadcn <- 0
input$omadc <- 0
input$omadlig <- 0
input$fertamt <- 0

# add in last values to trigger N storage and retranslocation in FUN
for (i in 1:length(input[,1])){
  if(input[i,"doy"] == 320){ # DOY 320 to match the DayCent spin up 
    input[i, "last"] <- 1
  }
}




# r Calculate Turnover --------------

input$froot_turnover_c <- 0 
input$froot_turnover_n <- 0
input$agrd_turnover_c <- 0
input$agrd_turnover_n <- 0

for (i in 2:length(input[,1])) {
  input$froot_turnover_c[i] <- 
    ((input$bglivcm[i-1] + input$bglivcj[i-1]) - (input$bglivcm[i] + input$bglivcj[i]))
  
  input$froot_turnover_n[i] <- 
    ((input$bglivnm[i-1] + input$bglivnj[i-1]) - (input$bglivnm[i] + input$bglivnj[i]))
  
  input$agrd_turnover_c[i] <- (input$aglivc[i-1] - input$aglivc[i])
  
  input$agrd_turnover_n[i] <- (input$aglivn[i-1] - input$aglivn[i])
  
  print(paste(ceiling((i/tail(length(input[,1])))*100), "% of turnover calculated", sep = ""))
}

# Remove negative turnover values- replace negatives with zero
input$froot_turnover_c[input$froot_turnover_c < 0] <- 0
input$froot_turnover_n[input$froot_turnover_n < 0] <- 0
input$agrd_turnover_c[input$agrd_turnover_c < 0] <- 0
input$agrd_turnover_n[input$agrd_turnover_n < 0] <- 0




# r Add Crop specific parameters  --------------

# The entire spin up period will have only prairie- using TMC4 temperate_tallgrass from DayCent crop.100 file because that is how Danielle spun up the model 

### add crop specific leaf litter fastfracs to input file
input$leaf_litter_fastfrac <- 0.773 # average of old and young leaves for TMC4

### add crop specific root litter fastfracs to input file
input$root_litter_fastfrac <- 0.736 # fine roots of TMC4

### add crop specific root diameter (mm) to input file
input$root_diameter <- 0.3 # TMC4 temperate_tallgrass in DayCent, mean value for big bluestem, indiangrass, and little bluestem. calculated in script "FUN CORPSE Ag_Model Input_Extract SRL from FRED.Rmd" 




# r Calculate Rhizosphere Fraction  --------------

# Calculate Rhizospere Size (rhizo_frac)

# Define parameters
total_soil_volume <- 30*100*100 # in cm3/m2, 30cm deep for 1 m2 area
zone <- 1 # This is the distance the rhizosphere extends from the root in mm, so here its 1 mm

# Calculate root length as mm root/m2
# juvenile and mature root C is in kg C/m2 in input file, multiply by 1000 to convert to g/m2 for this calculation then multiply by 2 to calculate biomass from carbon
# this is only fine root length
input$root_length <- (input$bglivcj+input$bglivcm)*1000*2*input$cropsrl

# Calculate rhizo_frac
# steps: 
# (1) Calculate root plus rhizosphere volume in mm3/m2 
# input$root_length*((input$root_diameter/2+zone)^2*pi
# (2) Calculate root volume (w/o rhizosphere)
# input$root_length*((input$root_diameter/2)^2*pi)
# (3) Calculate rhizosphere volume in mm3/m2 by difference of step 1- step 2 then divide by 1000 to convert to cm3/m2
# ((input$root_length*((input$root_diameter/2+zone)^2*pi) - (input$root_length*((input$root_diameter/2)^2*pi)))/1000
# (4) Calculate % of total soil volume composed of rhizosphere - divide step 3 by total_soil_volume


# Rhizo_frac calculation: % of total soil volume composed of rhizosphere 
input$rhizo_frac <- 
  (((input$root_length*((input$root_diameter/2+zone)^2*pi)) - 
      (input$root_length*((input$root_diameter/2)^2*pi)))/1000)/total_soil_volume
# minimum rhizosphere size 3%, we previously made the minimum 1% so this is fine
#input$rhizo_frac <- ifelse(input$rhizo_frac < 0.01, 0.01, input$rhizo_frac)


# r Export file for input into model --------------

write.csv(input, "input_1500_years_spinup.csv", row.names = FALSE)



