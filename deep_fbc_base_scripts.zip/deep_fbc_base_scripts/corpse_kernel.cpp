// =============================================================================
// CORPSE derivative kernel in C++
// 2026-08-21 SW
//
// A direct translation of CORPSE()/decompRate()/Vmax() from
// CORPSE_Functions_Bioenergy_V2_matrix.R. The R wrapper in
// CORPSE_Functions_Bioenergy_V2_rcpp.R keeps the same signature as the R
// version, so nothing in the driver scripts changes except the sourced file.
//
// Only the arithmetic lives here. Integration (pool + deriv * CORPSEstep),
// mixing, litter, root turnover, exudates, leaching, tillage, FUN and all
// recording stay in R.
//
// Pool column order is fixed by pool_column_names and asserted by the wrapper:
//   0 uFastC   1 uSlowC   2 uNecroC   3 pFastC  4 pSlowC  5 pNecroC
//   6 livingMicrobeC
//   7 uFastN   8 uSlowN   9 uNecroN  10 pFastN 11 pSlowN 12 pNecroN
//  13 inorganicN 14 CO2 15 livingMicrobeN
//
// Parameter vector layout, built once by prep_corpse_params_cpp():
//   0- 2 Vmaxref(Fast,Slow,Necro)      3- 5 Ea       6- 8 kC
//   9-11 eup                          12-14 nup    15-17 protection_rate
//  18 gas_diffusion_exp  19 minMicrobeC  20 Tmic  21 et  22 tProtected
//  23 frac_N_turnover_min  24 CN_Microbe  25 max_immobilization_rate
//  26 substrate_diffusion_exp  27 frac_turnover_slow  28 new_resp_units
// =============================================================================

#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericMatrix corpse_deriv_cpp(NumericMatrix SOM, double T, double theta,
                               NumericVector p, double claymod, bool Litter) {

  const int nsites = SOM.nrow();
  const double Rugas = 8.314472, Tref = 293.15;

  if (theta < 0.0) theta = 0.0;
  if (theta > 1.0) theta = 1.0;

  double aerobic_max = 1.0;
  if (p[28] > 0.5) {                       // new_resp_units
    const double trm = p[26] / (p[18] * (1.0 + p[26] / p[18]));
    aerobic_max = std::pow(trm, p[26]) * std::pow(1.0 - trm, p[18]);
  }
  const double eq1 = std::pow(theta, p[26]);
  const double eq2 = std::pow(1.0 - theta, p[18]) / aerobic_max;

  // Vmax is independent of site, so it is computed once
  double vmax[3];
  for (int k = 0; k < 3; ++k)
    vmax[k] = p[k] * std::exp(-p[3 + k] * (1.0 / (Rugas * T) - 1.0 / (Rugas * Tref)));

  const double CN = p[24];
  NumericMatrix d(nsites, 16);

  for (int s = 0; s < nsites; ++s) {

    const double micC = SOM(s, 6);
    const double sumU = SOM(s, 0) + SOM(s, 1) + SOM(s, 2);

    // ---- decomposition -----------------------------------------------------
    double dC[3], dN[3];
    for (int k = 0; k < 3; ++k) {
      const double uC = SOM(s, k), uN = SOM(s, 7 + k);
      double rate = (micC == 0.0) ? 0.0
                  : vmax[k] * eq1 * eq2 * (uC * micC / (sumU * p[6 + k] + micC));
      dC[k] = rate;
      dN[k] = (uC == 0.0) ? 0.0 : rate * (uN / uC);
    }

    // ---- microbial turnover ------------------------------------------------
    double microbeTurnover = (micC - p[19] * sumU) / p[20];
    if (microbeTurnover < 0.0) microbeTurnover = 0.0;
    const double maint    = microbeTurnover * (1.0 - p[21]);
    double overflow       = 0.0;
    const double deadC    = microbeTurnover * p[21];
    const double deadN    = deadC / CN;

    double Csup = 0.0, Nsup = 0.0;
    for (int k = 0; k < 3; ++k) { Csup += dC[k] * p[9 + k]; Nsup += dN[k] * p[12 + k]; }

    const double IMM = p[25] * 365.0 * SOM(s, 13) / (SOM(s, 13) + p[25]);

    double dmicC, dmicN, imbal;
    if ((Csup - maint) > ((Nsup + IMM) * CN)) {            // N limited
      imbal    = -IMM;
      dmicC    = (Nsup + IMM) * CN - microbeTurnover * p[21];
      dmicN    = (Nsup + IMM) - microbeTurnover * p[21] / CN;
      overflow = Csup - maint - (Nsup + IMM) * CN;
    } else if ((Csup - maint) >= Nsup * CN) {              // immobilisation
      imbal = -((Csup - maint) / CN - Nsup);
      dmicC = Csup - microbeTurnover;
      dmicN = (Csup - maint) / CN - microbeTurnover * p[21] / CN;
    } else {                                               // C limited
      dmicC = Csup - microbeTurnover;
      dmicN = (Csup - maint) / CN - microbeTurnover * p[21] / CN;
      imbal = Nsup - (Csup - maint) / CN;
    }

    double CO2prod = maint + overflow;
    for (int k = 0; k < 3; ++k) CO2prod += dC[k] * (1.0 - p[9 + k]);

    d(s, 6) = dmicC; d(s, 15) = dmicN; d(s, 14) = CO2prod; d(s, 13) = imbal;

    // ---- protection / deprotection ----------------------------------------
    for (int k = 0; k < 3; ++k) {
      const double prate = Litter ? 0.0 : p[15 + k] * claymod;
      const double ptC = SOM(s, 3 + k)  / p[22], ppC = SOM(s, k)     * prate;
      const double ptN = SOM(s, 10 + k) / p[22], ppN = SOM(s, 7 + k) * prate;
      d(s, k)      = -dC[k] + ptC - ppC;
      d(s, 3 + k)  =  ppC - ptC;
      d(s, 7 + k)  = -dN[k] + ptN - ppN;
      d(s, 10 + k) =  ppN - ptN;
    }

    // ---- dead microbe routing ---------------------------------------------
    d(s, 2) += deadC * (1.0 - p[27]);
    d(s, 1) += deadC * p[27];
    const double tNmin  = deadN * p[23];
    const double tNslow = deadN * p[27];
    double nonAssimN = 0.0;
    for (int k = 0; k < 3; ++k) nonAssimN += dN[k] * (1.0 - p[12 + k]);
    d(s, 9) += deadN - tNmin - tNslow;
    d(s, 8) += tNslow;
    d(s, 13) += tNmin + nonAssimN;
  }

  return d;
}
