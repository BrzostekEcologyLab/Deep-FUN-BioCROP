# =============================================================================
# 2026-08-21 SW -- RCPP VERSION
#
# Same as the FAST version, except that the CORPSE derivative runs in C++.
# The main loop, the model logic and every CORPSE call site are unchanged.
#
# NUMERICS: this version is NOT bit-identical to the R versions. C++ evaluates
# in a different order and may fuse multiply-add, so expect agreement to about
# 1e-14 relative -- verified over 800 randomised pool states. Use the FAST
# version when you need exactly reproducible output.
#
# REQUIRES: Rcpp, a C++ compiler (r-base-dev + build-essential on Ubuntu),
# CORPSE_Functions_Bioenergy_V2_rcpp.R and corpse_kernel.cpp.
# =============================================================================
# 2026-08-21 SW -- FAST VERSION (pure R)
#
# Three optimisations, all numerically identical to the version this was
# generated from. No model logic, parameter, or ordering has changed.
# Every change is marked "FAST:".
#
#   1. prep_corpse_params() called once on each of the five params objects, so
#      CORPSE stops re-extracting them from a data.frame 6 million times.
#      Measured: CORPSE 283 us -> 178 us per call (1.59x).
#
#   2. The 12 input columns used inside the main loop are hoisted to plain
#      numeric vectors (in_doy, in_rhizo_frac, ...). 22 lookups per timestep
#      through [.data.frame was 13.7 percent of loop time.
#
#   3. max(input$nyr) hoisted out of the progress bar. It was scanning all
#      547500 rows twice per timestep: about 881 s (15 min) of a 1500 year run
#      spent recomputing a constant. This one is invisible in a short test run.
#
# Requires CORPSE_Functions_Bioenergy_V2_matrix_fast.R.
# =============================================================================
# =============================================================================
# 2026-08-14 SW -- MATRIX VERSION
#
# Pools are numeric matrices with named columns instead of data.frames. This is
# a data-structure change only: verified to reproduce the data.frame version
# bit for bit over a 3 year run. Requires CORPSE_Functions_Bioenergy_V2_matrix.R
# (that file also accepts data.frames, so it is a drop-in for either script).
#
# Every change is marked "MATRIX:". They are:
#   - pool objects built with matrix(..., dimnames=) rather than data.frame()
#   - pool$col            -> pool[, "col"]      (throughout the loop)
#   - *_int coerced with as.matrix() when seeding the pools
#   - do.call(rbind, *_final_list) wrapped in as.data.frame() once after the
#     loop, so all downstream dplyr and export code is unchanged
#   - DOMleach constants hoisted out of the loop
# =============================================================================
# 2026-08-14 SW -- single-site revision of spinup_baseline_oh.R
#
# Every change is marked inline with "2026-08-14 SW".
#
# SITE REMOVAL (nsites 2 -> 1)
#   - column duplications kept as 1-column matrices, so all [i,j] indexing
#     is unchanged
#   - 22 pool row-duplication lines removed
#   - rootNdemand / leafNdemand / FUNstorageN second columns removed
#   - leafN[,2] KEPT: leafN is ncol = 4, not a site matrix
#   - FUN loop replaced by a braced block with j <- 1
#
# BUG FIXES
#   - soil mixing no longer multiplies returned soil by root_pool_scale_*
#     (this was destroying ~58-62 percent of layer C per year below 30 cm)
#   - six negativity guards: min(x<0) -> min(x)<0
#   - inorganic-N cascade: donations use the donating layer's iN_loss_rate
#   - total_Nacq_storage[i] -> [i,j]; FUN_shared_inorganicN[1] -> [j]
#   - litter_productionN reads leafN[,4] rather than a 0/1 flag column
#   - zero guard before the fracN* split
#
# DEPTH-SPECIFIC RHIZOSPHERE (2026-08-14 SW)
#   - rhizo_frac_30/50/70/100 <- rhizo_frac * root_pool_scale_*, defined at the
#     top of the main loop; DayCent's rhizo_frac describes 0-30 cm only
#   - used for EVERY within-layer bulk/rhizosphere split: soil mixing, root
#     turnover C and N, fungal production, and newsoil
#   - initial values split between bulk and rhizosphere with the day-1
#     fraction, preserving each layer total
#
# DELIBERATELY NOT CHANGED (per SW: small and persistent across FUN-CORPSE)
#   - inorganic N is perturbed by the mixing block, then overwritten on the
#     next timestep; the recorded inorganicN column is therefore an artefact
#   - pool recording happens after decomposition but before the day's inputs,
#     so each exported row lags the inputs by one day
# =============================================================================

# overview ----
# Code is originally from Stephanie Juice
# "FUN-BioCROP_ECO2_Spin Up_1500 yrs.Rmd"
# which is the most up to date spinup file
# SW is adapting to do spinup at multiple soil depths for Miscanthus deep C study
# to represent fields at the UIUC bioenergy farm. This uses the 
# LIDET litter decomposition parameters. 

# This model estimates processes at four differently spaced depth intervals
# using initial DayCent predictions to 30 cm depth
# 0-30 (30)
# 31-50 (50)
# 51-70 (70)
# 71-100 (100)
# differences in soil volume are accounted for primarily by scaling data related to 
# root biomass/rhizosphere size in each depth compartment by the fraction
# of roots expected to be at each depth, using data derived from Zoe Pagliaro and
# a logistic relationship of cumulative root fraction

# This model run is to spin up FUN-BioCROP to simulate the initial prairie conditions for 1500 years.

# Because it is a spin up file: 
#   - pct_soil_tilled is set to 0
#   - harvest is commented out 


# remove all functions clear memory -----

rm(list=ls(all=TRUE)) 

# set wd & project name ----

## SET LOWER THAN 1501 FOR TROUBLESHOOTING ONLY
num_yr <- 1501

setwd( "/home/soren/Dropbox/WVU_postdoc/projects/weber_deep_fbc/")

# name and describe each model project, prevents overwriting

proj_name <- "2026-09-11_working_1_spinup_rcpp"

script_name <- "experimental_models/working_1_spinup_rcpp.R"

# description ----

description <- 
  " Getting carbon expended per depth.
Reparameterized baseline spinup model with protection 1.25× and Vmax of necro 0.75×"

if ( file.exists( file.path( "experimental_models" , paste0( proj_name ) ) ) ){
  stop( "Project name already in use. Choose another name.")
} else {
  dir.create(  file.path( "experimental_models" , paste0( proj_name ) ) )
  dir.create(  file.path( "experimental_models" , paste0( proj_name ) , "01_output" ) )
  
  proj_dir <- file.path( "experimental_models", proj_name )
  snap_dir <- file.path( proj_dir, "00_source_snapshot" )
  cat( 
    paste0( 
      format(Sys.time(), "%Y-%m-%d") , 
      "\n" ,
      format(Sys.time(), "%T") , 
      "\n" ,
      "project:" , proj_name ,
      "\n" ,
      "script:", script_name ,
      "\n" ,
      "description:\n" , description ,
      "\n",
      "R:", R.version.string,
      "\n",
      "snapshot:", snap_dir,
      "\n" ) ,
       file = file.path( "experimental_models" , paste0( proj_name ) , paste0( proj_name , ".md" ) ) ) 

  # ---- source snapshot -------------------------------------------------------
  # Copies every file that defines this run into the output directory, so the
  # result stays reproducible after the working copies are edited.


  dir.create( snap_dir, showWarnings = FALSE, recursive = TRUE )

  # locate this script: works under Rscript, source(), and RStudio Run
  this_script <- local({
    a <- commandArgs( trailingOnly = FALSE )
    f <- sub( "^--file=", "", a[ grep( "^--file=", a ) ] )
    if ( length( f ) ) return( normalizePath( f, mustWork = FALSE ) )
    for ( i in rev( sys.parents() ) ) {
      of <- sys.frame( i )$ofile
      if ( !is.null( of ) ) return( normalizePath( of, mustWork = FALSE ) )
    }
    if ( requireNamespace( "rstudioapi", quietly = TRUE ) &&
         rstudioapi::isAvailable() ) {
      p <- try( rstudioapi::getSourceEditorContext()$path, silent = TRUE )
      if ( !inherits( p, "try-error" ) && nzchar( p ) )
        return( normalizePath( p, mustWork = FALSE ) )
    }
    normalizePath( script_name, mustWork = FALSE )   # fall back to the label
  })

  # every file that determines the result
  snapshot_files <- c(
    this_script,
    "CORPSE_Functions_Bioenergy_V2_rcpp.R",
    "corpse_kernel.cpp",
    "00_spinup/initial_layers.csv"
  )

  snap_rows <- list()
  for ( f in snapshot_files ) {
    if ( !file.exists( f ) ) {
      warning( "snapshot: not found, skipping -- ", f )
      next
    }
    file.copy( f, file.path( snap_dir, basename( f ) ), overwrite = TRUE )
    snap_rows[[ length( snap_rows ) + 1L ]] <- data.frame(
      file     = basename( f ),
      source   = normalizePath( f, mustWork = FALSE ),
      bytes    = file.info( f )$size,
      modified = format( file.info( f )$mtime, "%Y-%m-%d %H:%M:%S" ),
      sha1     = if ( requireNamespace( "digest", quietly = TRUE ) )
        digest::digest( file = f, algo = "sha1" ) else NA_character_,
      stringsAsFactors = FALSE )
  }
  write.csv( do.call( rbind, snap_rows ),
             file.path( snap_dir, "snapshot_manifest.csv" ), row.names = FALSE )

  # catch a stale script_name label before it misattributes the run
  if ( basename( this_script ) != basename( script_name ) ) {
    warning( "script_name says '", basename( script_name ),
             "' but this file is '", basename( this_script ),
             "' -- script_name may be stale." )
  }
}


# packages & functions -----

library( dplyr ) 
library( tidyr ) 

## exporting
export <- 
  function( object ){
    write.csv( object , 
               paste0( 
                 file.path( "experimental_models" ,  proj_name , paste0( "01_output" , "/" ) ) , 
                 substitute( object ) , ".csv") , 
               row.names = FALSE)
  }

## diagnostic function
crash <- function( message ) { stop( message , call. = FALSE ) }

## CORPSE decomposition function

# 2026-08-14 SW MATRIX: now sources the matrix version of the CORPSE functions
# 2026-08-21 SW RCPP: sources the Rcpp CORPSE wrapper. corpse_kernel.cpp must sit
# in the same directory as that file. prep_corpse_params() below is
# unchanged -- in this version it builds the flat vector the C++ kernel
# indexes positionally.
source( "~/Dropbox/WVU_postdoc/projects/weber_deep_fbc/CORPSE_Functions_Bioenergy_V2_rcpp.R" )

# initial values ----

# Initial C and N pool values for bulk, 
# rhizosphere and litter layers (kg C or N/m2) - 
# start all with 0.0001 kg C/m2 of living microbe C 
# 0.000014 kg C/m2 of living microbe N [ 0 in Steph's other code]
# and 0 of everything else

# soil C scalars
# From calibration_validation.R script
# pits 2, 4, 5 from Pagliaro et al. 2026
soc_scalars <- read.csv( "calibration_validation/soc_scalars.csv")
soilCscalar50   <- soc_scalars[["soc_scalar_50"]]
soilCscalar70   <- soc_scalars[["soc_scalar_70"]]
soilCscalar100  <- soc_scalars[["soc_scalar_100"]]


# 2026-08-14 SW: this block now only READS the file and sets the litter layer. The
# bulk / rhizosphere compartments are built further down, after
# root_pool_scale_* and input exist, so the split can use the depth-specific
# rhizosphere fraction. See "PARTITION THE INITIAL VALUES" below.
initial_layers_int <- read.csv( "00_spinup/initial_layers.csv" , header=TRUE )

# litter is a single compartment, not split between bulk and rhizosphere
litter30_int <- initial_layers_int


# Soil temperature and moisture- both at 10 cm, average value of Energy Farm flux tower data from 7/2008-3/2016
soilT <- as.matrix( read.csv( "00_spinup/FluxTower_AvgSoilT.csv" ) )
soilVWC <- as.matrix( read.csv( "00_spinup/FluxTower_AvgSoilVWC.csv" ) )

# Input file with DayCent values, tall grass prairie 
# this input file was made for the LIDET paper spin up
input <- read.csv( "00_spinup/input_file_preparation/input_1500_years_spinup.csv" )  # in kg C/m2

# change yr in the file, currently starts at year 346
input$yr <- input$yr - 345

# TOGGLE  FOR THE NUMBER OF YEARS TO DO SPINUP FOR
input <- 
input %>% 
  filter( yr < num_yr )


# root depth distribution -----
# From calibration_validation.R script
# pits 2, 4, 5 from Pagliaro et al. 2026
rdd <- read.csv( "calibration_validation/root_fraction_logistic_parameters.csv")

# can vary rate and midpoint in sensitivity analyses
rate <- rdd$root_fraction_rate
midpoint <- rdd$root_fraction_midpoint

# getting layer fractions

layer_fracs <- function( rate , mid , edges = c(0, 30, 50, 70, 100) ) {
  cum <- 1 / ( 1 + exp( -rate * ( log( edges[-1] ) - mid ) ) )
  out <- diff( c( 0 , cum ) )
  names( out ) <- paste0( head( edges , -1 ) , "_" , edges[-1] )
  out
}

root_layers <- layer_fracs( rate , midpoint ) 

roots_30  <- root_layers[["0_30"]]
roots_50  <- root_layers[["30_50"]]
roots_70  <- root_layers[["50_70"]]
roots_100 <- root_layers[["70_100"]]

root_pool_scale_30  <- roots_30  / roots_30
root_pool_scale_50  <- roots_50  / roots_30
root_pool_scale_70  <- roots_70  / roots_30
root_pool_scale_100 <- roots_100  / roots_30


# DOM leaching rates, 
# From calibration_validation.R script
# pits 2, 4, 5 from Pagliaro et al. 2026
dom_leach <- read.csv( "calibration_validation/DOMleach.csv")

DOMleach30  <- dom_leach[dom_leach$depth_cm == "0_30", ]$DOMleach
DOMleach50  <- dom_leach[dom_leach$depth_cm == "30_50", ]$DOMleach
DOMleach70  <- dom_leach[dom_leach$depth_cm == "50_70", ]$DOMleach
DOMleach100 <- dom_leach[dom_leach$depth_cm == "70_100", ]$DOMleach

# these are removed as they are only needed to calculate the root_pool_scale
# and add the domleaching rates into the model
rm( dom_leach , rate, midpoint , roots_30 , roots_50 , roots_70 , roots_100 )

# load parameters -----

### Tillage Parameters
# assign values for percent soil tilled and percent protected C moved to unprotected C following tillage

pct_soil_tilled <- 0 # set to 0 for spin up, usually it is 0.15. This is the percent of soil assigned to the till layer (rhizo and bulk only)
tillPtoUP <- 0.3 # percent of protected C and N moved to unprotected pools following tillage
# tillPtoUP is 0.2 in Juice et al. 2025 GCB Bioenergy


# Set the number of plots and years for running the model
nyears <- max(input$nyr)
nsites <- 1 # 2026-08-14 SW: was 2. The two sites were exact duplicates -- every
            # driver was built by copying column 1 into column 2 -- so the
            # second site carried no information and only served to hide
            # single-index bugs. See the notes at each duplication site.
timestep <- length(input[,1]) # length of model run in days
CORPSEstep <- 1/365 # used to scale the data to be a daily value in the CORPSE function
FUNstep <- 365 # used in model loops for DOY 


##Data frame with CORPSE parameters
# These are defined in the CORPSE function
params <- data.frame(
  "Vmaxref_Fast" = 9.0,
  "Vmaxref_Slow" = 0.25 ,
  "Vmaxref_Necro"= 4.5,
  "Ea_Fast" = 5e3,
  "Ea_Slow" = 30e3,
  "Ea_Necro"= 3e3,
  "kC_Fast" = 0.01,
  "kC_Slow" = 0.01,
  "kC_Necro"= 0.01,
  "gas_diffusion_exp" = 0.6,
  "minMicrobeC" = 1e-3,
  "Tmic"= 0.25,
  "et" = 0.6,
  "eup_Fast" = 0.6,
  "eup_Slow"= 0.1,
  "eup_Necro" = 0.6,
  "tProtected" = 100.0,
  "frac_N_turnover_min" = 0.2,
  "protection_rate_Fast" = 0.7,
  "protection_rate_Slow" = 0.001, 
  "protection_rate_Necro" = 4.0,
  "nup_Fast" = 0.3,
  "nup_Slow" = 0.3,
  "nup_Necro" = 0.3,
  "CN_Microbe" = 7,
  "max_immobilization_rate" = 3.65,
  "substrate_diffusion_exp" = 1.5,
  "new_resp_units" = TRUE,
  "iN_loss_rate" = 5.0,
  "frac_turnover_slow" = 0.2
)

# # # # # # # # # # #
# params_litter is ONLY for the CORPSE litter section, not the rest of the model
# litter specific parameters from LIDET parameterization
# inherits everything from params and then we change values to match LIDET
params_litter <- params
params_litter$Vmaxref_Fast <- 2 # 9.0 in original params (above)
params_litter$Vmaxref_Slow <- 0.35 # 0.25 in original params (above)
params_litter$Ea_Slow <- 25e3 # 30e3 in original params (above)
params_litter$kC_Fast <- 0.007 # 0.01 in original params (above)
params_litter$kC_Slow <- 0.005 # 0.01 in original params (above)
params_litter$kC_Necro <- 0.007 # 0.01 in original params (above)
params_litter$eup_Slow <- 0.001 # 0.1 in original params (above)


# # # # # # # # # # #
# depth specific parameters for parameterization

# Working model reparameterization
# protection 1.25×
# necro 0.75×

prot_rate_scale <- 1.25
Vmax_scale      <- 0.75

params50 <- params
params50$protection_rate_Fast   <- prot_rate_scale * params50$protection_rate_Fast
params50$protection_rate_Slow   <- prot_rate_scale * params50$protection_rate_Slow
params50$protection_rate_Necro  <- prot_rate_scale * params50$protection_rate_Necro
params50$Vmaxref_Necro          <- Vmax_scale      * params50$Vmaxref_Necro

params70 <- params50
params70$protection_rate_Fast   <- prot_rate_scale * params70$protection_rate_Fast
params70$protection_rate_Slow   <- prot_rate_scale * params70$protection_rate_Slow
params70$protection_rate_Necro  <- prot_rate_scale * params70$protection_rate_Necro
params70$Vmaxref_Necro          <- Vmax_scale      * params70$Vmaxref_Necro

params100 <- params70
params100$protection_rate_Fast  <- prot_rate_scale * params100$protection_rate_Fast
params100$protection_rate_Slow  <- prot_rate_scale * params100$protection_rate_Slow
params100$protection_rate_Necro <- prot_rate_scale * params100$protection_rate_Necro
params100$Vmaxref_Necro         <- Vmax_scale      * params100$Vmaxref_Necro


# 2026-08-21 SW FAST: PRECOMPUTE THE CORPSE PARAMETER VECTORS
# ---------------------------------------------------------------------------
# CORPSE used to pull its parameters out of these data.frames on every call --
# six unlist() calls, measured at 69 us of a 292 us call, repeated 6 million
# times over a 1500 year spin up. prep_corpse_params() does that extraction
# once and caches it on the object as an attribute.
#
# The objects stay data.frames: params$Vmaxref_Fast still works and
# params_export is unchanged. This MUST come after every parameter edit above;
# if a value is changed later, re-run prep_corpse_params() on that object or
# the cached vector will be stale.
#
# Numerically identical -- verified bit for bit over 600 randomised pool states.
params        <- prep_corpse_params( params )
params_litter <- prep_corpse_params( params_litter )
params50      <- prep_corpse_params( params50 )
params70      <- prep_corpse_params( params70 )
params100     <- prep_corpse_params( params100 )



##Set fixed parameter values for CORPSE and FUN

##CORPSE fixed parameters
froot_turnover_fraction <- 1/365 # sets daily proportion of bulk and rhizo that are mixed together
litter_transfer_to_soil <- 1/365 # sets daily proportion of litter mixed into bulk and rhizo
porosity <- 0.5 # for theta_step calculation with soilVWC

##FUN fixed parameters
storageCN <- 1 #This number is the C:N ratio of glutamic acid
exudate_CN <- 30
cost_param_mult <- 1.0

##FUN Cost parameters (kg C m3)
##Fixed parameters for Costfix equation
a_fix <- (-3.62)
b_fix <- 0.27
c_fix <- 25.14
s_fix <- (-30)

##Parameters from Github
##FUN Resorb cost parameters (cost_resorb)
kR <- 0.005 ##controls cost of retranslocation associated with leaf N

##FUN Non-mycorrhizal cost parameters ## multipliers turned off 10/14/2020 cw
Non_kN <- (0.6/365) 
Non_kC <- (0.01/365) 

##FUN Mycorrhizal cost parameters 
kC <- (0.05/365) 
kN <- (0.1/365) 


##Set CORPSE input values for C and N input rates

claymod <- 1.0  #Scalar that modifies the ability of clays to sorb and protect C

exudate_Cinput <- 0.03
exudate_Ninput <- 0.001

inorg_Ndep <- 0 # Stephanie Juice: 10/24/2022 - changed from 0.01


# prepare data streams -----

# 2026-08-14 SW: the block that copied row 1 into row 2 of every initial-value
# object has been removed. With nsites <- 1 each pool object is a single row.

# 30


# 50 

# 70 

# 100 


# names( input )

# Define daily values based on "input" file of DayCent data
# the duplicated columns are for the 2sp
daily_ANPP <- input$anpp  # 2026-08-14 SW: 1 site; kept as a 1-col matrix

# ---------------------------------------------------------------------------
# 2026-08-14 SW: PARTITION THE INITIAL VALUES BETWEEN BULK AND RHIZOSPHERE
#
# Previously every compartment (bulk, rhizo, tilled, untilled) was handed a
# full copy of initial_layers.csv, so the rhizosphere started the same size as
# bulk at every depth -- inconsistent with a rhizosphere that shrinks with
# depth.
#
# Each layer's TOTAL is preserved exactly as before (int_pairs_per_layer = 2,
# i.e. bulk + rhizo = 2x the file, as when both got a full copy). Only the
# SPLIT changes, using the same depth-specific rhizosphere fraction the main
# loop uses. Set int_pairs_per_layer <- 1 to instead read the file as the
# layer total.
#
# rhizo_frac varies daily, so the day-1 value seeds the split. The mixing term
# relaxes any initialisation mismatch on a ~1 year timescale, so this matters
# far less than the flux structure over a 1501 year spin up.
# ---------------------------------------------------------------------------
int_pairs_per_layer <- 2

rhizo_frac_int     <- input$rhizo_frac[1]
rhizo_frac_int_30  <- rhizo_frac_int * root_pool_scale_30
rhizo_frac_int_50  <- rhizo_frac_int * root_pool_scale_50
rhizo_frac_int_70  <- rhizo_frac_int * root_pool_scale_70
rhizo_frac_int_100 <- rhizo_frac_int * root_pool_scale_100

# layer totals (bulk + rhizosphere)
layer30_int  <- initial_layers_int * int_pairs_per_layer
layer50_int  <- initial_layers_int * int_pairs_per_layer * soilCscalar50
layer70_int  <- initial_layers_int * int_pairs_per_layer * soilCscalar70
layer100_int <- initial_layers_int * int_pairs_per_layer * soilCscalar100

# 30 -- untilled and tilled halves each split by the same fraction
bulk30_int       <- layer30_int * ( 1 - rhizo_frac_int_30 )
rhizo30_int      <- layer30_int * rhizo_frac_int_30
bulk30_till_int  <- layer30_int * ( 1 - rhizo_frac_int_30 )
rhizo30_till_int <- layer30_int * rhizo_frac_int_30

# 50
bulk50_int  <- layer50_int * ( 1 - rhizo_frac_int_50 )
rhizo50_int <- layer50_int * rhizo_frac_int_50

# 70
bulk70_int  <- layer70_int * ( 1 - rhizo_frac_int_70 )
rhizo70_int <- layer70_int * rhizo_frac_int_70

# 100
bulk100_int  <- layer100_int * ( 1 - rhizo_frac_int_100 )
rhizo100_int <- layer100_int * rhizo_frac_int_100

# CO2 is a cumulative respiration counter, not a stock: it must not be
# partitioned or scaled by depth
for ( .nm in c( "bulk30_int","rhizo30_int","bulk30_till_int","rhizo30_till_int",
                "bulk50_int","rhizo50_int","bulk70_int","rhizo70_int",
                "bulk100_int","rhizo100_int" ) ) {
  .tmp <- get( .nm ); .tmp$CO2 <- initial_layers_int$CO2; assign( .nm , .tmp )
}
rm( .tmp , .nm )

# the split must preserve each layer total
stopifnot(
  all( abs( ( bulk30_int  + rhizo30_int  ) - layer30_int  ) < 1e-12 ),
  all( abs( ( bulk50_int  + rhizo50_int  ) - layer50_int  ) < 1e-12 ),
  all( abs( ( bulk70_int  + rhizo70_int  ) - layer70_int  ) < 1e-12 ),
  all( abs( ( bulk100_int + rhizo100_int ) - layer100_int ) < 1e-12 ) )




# daily root production
# these scales ensure that the total amount of input biomass is the same
# as what DayCent gives us, the amounts are just distributed over 100 cm in depth rather
# than the top 30 alone

daily_root_prod30 <- input$bnpp * root_pool_scale_30
daily_root_prod30 <- cbind( daily_root_prod30 )

daily_root_prod50 <- input$bnpp * root_pool_scale_50
daily_root_prod50 <- cbind( daily_root_prod50 )

daily_root_prod70 <- input$bnpp * root_pool_scale_70
daily_root_prod70 <- cbind( daily_root_prod70 )

daily_root_prod100 <- input$bnpp * root_pool_scale_100
daily_root_prod100 <- cbind( daily_root_prod100 )

daily_root_prod <-  daily_root_prod30 + daily_root_prod50 + daily_root_prod70 + daily_root_prod100

# NPP 
# root biomass in kg C/m2
daily_NPP <- daily_ANPP + daily_root_prod

# 30 
daily_root_bio30 <- ( input$bglivcm + input$bglivcj  ) * root_pool_scale_30 
daily_root_bio30 <- cbind( daily_root_bio30 )

# 50
daily_root_bio50 <- (input$bglivcm + input$bglivcj) * root_pool_scale_50  
daily_root_bio50 <- cbind( daily_root_bio50 )

# 70
daily_root_bio70 <- (input$bglivcm + input$bglivcj) * root_pool_scale_70
daily_root_bio70 <- cbind( daily_root_bio70 )

# 100
daily_root_bio100 <- (input$bglivcm + input$bglivcj) * root_pool_scale_100
daily_root_bio100 <- cbind( daily_root_bio100 )

# juvenile root C biomass- also kg C/m2
# 30
daily_root_bio_juv30 <- input$bglivcj * root_pool_scale_30
daily_root_bio_juv30 <- cbind( daily_root_bio_juv30 )

# 50
daily_root_bio_juv50 <- input$bglivcj * root_pool_scale_50 
daily_root_bio_juv50 <- cbind( daily_root_bio_juv50 )

# 70
daily_root_bio_juv70 <- input$bglivcj * root_pool_scale_70
daily_root_bio_juv70 <- cbind( daily_root_bio_juv70 )

# 100
daily_root_bio_juv100 <- input$bglivcj * root_pool_scale_100
daily_root_bio_juv100 <- cbind( daily_root_bio_juv100 )


daily_root_bio_juv_sum <- 
  daily_root_bio_juv30 + 
  daily_root_bio_juv50 + 
  daily_root_bio_juv70 +
  daily_root_bio_juv100


# !Q do I need to have different turnover rates for different depths?

froot_turnover_c <- input$froot_turnover_c

froot_turnover_n <- input$froot_turnover_n

agrd_turnover_c <- input$agrd_turnover_c

agrd_turnover_n <- input$agrd_turnover_n

# set initial Conditions -----

##Set CORPSE initial conditions using data streams

##Empty data frame with column names for:
# pools -- u=unprotected, p=protected
# chem_types -- Fast, Slow, Necro
# for each soil compartment
pool_column_names <- c("uFastC", "uSlowC", "uNecroC",
                       "pFastC", "pSlowC", "pNecroC",
                       "livingMicrobeC",
                       "uFastN", "uSlowN", "uNecroN",
                       "pFastN", "pSlowN", "pNecroN",
                       "inorganicN",
                       "CO2",
                       "livingMicrobeN")

ncolnames <- length(pool_column_names)

# 2026-08-14 SW MATRIX: the pool objects are matrices with named columns, not
# data.frames. Arithmetic on a small data.frame dispatches through
# Ops.data.frame, which loops columns, re-checks types and rebuilds attributes
# on every single operation; on a 1 x 16 object that overhead dominates. All
# pool arithmetic in this script is whole-object (pool + results*CORPSEstep,
# pool - soilMix, pool * scalar), so switching to matrices is a pure
# data-structure change with identical numerics.
#
# Consequences elsewhere in this file, all marked "MATRIX:":
#   pool$col            -> pool[, "col"]
#   min(pool)           unchanged (works on matrices)
#   *_final_list[[i]]   now holds matrices; do.call(rbind, .) still works and
#                       is much faster on matrices than on data.frames
#   the *_final objects are converted back to data.frames once, after the
#   loop, so every downstream dplyr / export step is untouched.
bulk30 <- matrix(0, ncol = ncolnames, nrow = nsites,
                 dimnames = list(NULL, pool_column_names))

# 30 
bulk30 <- bulk30
rhizo30 <- bulk30
litter30 <- bulk30
bulk30_till <- bulk30 
rhizo30_till <- bulk30

# 50
bulk50 <- bulk30
rhizo50 <- bulk30

# 70 
bulk70 <- bulk30
rhizo70 <- bulk30

# 100 
bulk100 <- bulk30
rhizo100 <- bulk30


##Set up lists to hold CORPSE model outputs
# bulk, rhizosphere, and litter layers (as they change over time)

# 30 
bulk30_final_list <- list()
rhizo30_final_list <- list()
litter30_final_list <- list()
bulk30_till_final_list <- list() 
rhizo30_till_final_list <- list()

# 50
bulk50_final_list <- list()
rhizo50_final_list <- list()

# 70
bulk70_final_list <- list()
rhizo70_final_list <- list()

# 100
bulk100_final_list <- list() 
rhizo100_final_list <- list()

# Preallocated matrices rather than lists: this is the same reason the pools
# are matrices, and it avoids building 4 x 33580 list elements.
c_expend_cols <- c("30","50","70","100")
fungal_prod_per_depth   <- matrix(0, nrow = timestep, ncol = 4,
                                  dimnames = list(NULL, paste0("fungal_prod_", c_expend_cols)))
root_exude_per_depth    <- matrix(0, nrow = timestep, ncol = 4,
                                  dimnames = list(NULL, paste0("root_exude_", c_expend_cols)))
root_turnover_per_depth <- matrix(0, nrow = timestep, ncol = 4,
                                  dimnames = list(NULL, paste0("root_turnover_c_", c_expend_cols)))

## CORPSE assumes that inorganic N is the same across layers
# this may be the issue - there may be a problem with assuming
# the same amount of inorganic N across layers
# see if this cause

##Initializing shared inorganic N pool 
shared_inorganicN30 <- numeric(nsites) # 2sp
shared_inorganicN50 <- numeric(nsites)
shared_inorganicN70 <- numeric(nsites)
shared_inorganicN100 <- numeric(nsites)

##Initial Values for all layers (all units are in kg/m-2) 

# 30
# 2026-08-14 SW MATRIX: the *_int objects are data.frames built from the csv, so they
# are coerced once here on assignment into the matrix pools.
bulk30[1:nsites, 1:ncolnames] <- as.matrix(bulk30_int[1:nsites, 1:ncolnames])
bulk30[, "livingMicrobeN"] <- bulk30[, "livingMicrobeC"]/params$CN_Microbe

rhizo30[1:nsites, 1:ncolnames] <- as.matrix(rhizo30_int[1:nsites, 1:ncolnames])
rhizo30[, "livingMicrobeN"] <- rhizo30[, "livingMicrobeC"]/params$CN_Microbe

bulk30_till[1:nsites, 1:ncolnames] <- as.matrix(bulk30_till_int[1:nsites, 1:ncolnames])
bulk30_till[, "livingMicrobeN"] <- bulk30_till[, "livingMicrobeC"]/params$CN_Microbe

rhizo30_till[1:nsites, 1:ncolnames] <- as.matrix(rhizo30_till_int[1:nsites, 1:ncolnames])
rhizo30_till[, "livingMicrobeN"] <- rhizo30_till[, "livingMicrobeC"]/params$CN_Microbe

litter30[1:nsites, 1:ncolnames] <- as.matrix(litter30_int[1:nsites, 1:ncolnames])
litter30[, "livingMicrobeN"] <- litter30[, "livingMicrobeC"]/params_litter$CN_Microbe

# 50
bulk50[1:nsites, 1:ncolnames] <- as.matrix(bulk50_int[1:nsites, 1:ncolnames])
bulk50[, "livingMicrobeN"] <- bulk50[, "livingMicrobeC"]/params50$CN_Microbe

rhizo50[1:nsites, 1:ncolnames] <- as.matrix(rhizo50_int[1:nsites, 1:ncolnames])
rhizo50[, "livingMicrobeN"] <- rhizo50[, "livingMicrobeC"]/params50$CN_Microbe

# 70
bulk70[1:nsites, 1:ncolnames] <- as.matrix(bulk70_int[1:nsites, 1:ncolnames])
bulk70[, "livingMicrobeN"] <- bulk70[, "livingMicrobeC"]/params70$CN_Microbe

rhizo70[1:nsites, 1:ncolnames] <- as.matrix(rhizo70_int[1:nsites, 1:ncolnames])
rhizo70[, "livingMicrobeN"] <- rhizo70[, "livingMicrobeC"]/params70$CN_Microbe

# 100
bulk100[1:nsites, 1:ncolnames] <- as.matrix(bulk100_int[1:nsites, 1:ncolnames])
bulk100[, "livingMicrobeN"] <- bulk100[, "livingMicrobeC"]/params100$CN_Microbe

rhizo100[1:nsites, 1:ncolnames] <- as.matrix(rhizo100_int[1:nsites, 1:ncolnames])
rhizo100[, "livingMicrobeN"] <- rhizo100[, "livingMicrobeC"]/params100$CN_Microbe

# 2026-01-20 SW turned this off because I think it's bad
# shared_inorganicN <- bulk30[, "inorganicN"] 



# load FUN data and set up matrices ----

k <- 1:FUNstep

# changed length to nrow in the two for loops for root and leaf N demand, if error check

##First calculate amount of  root production and N needed - how much N needed for the timestep
# root N demand - daily N used to produce new belowground biomass
rootNdemand <- matrix(0, nrow = timestep, ncol = nsites)
for (i in 2:nrow(rootNdemand)) {
  rootNdemand[i] <- (input$bglivnj[i] + input$bglivnm[i]) -
    (input$bglivnj[i-1] + input$bglivnm[i-1])
}
rootNdemand[rootNdemand < 0] <- 0
# 2026-08-14 SW: 1 site -- second column removed (rootNdemand[,2] <- rootNdemand[,1])


# leafNdemand- daily N used to produce new aboveground biomass
leafNdemand <- matrix(0, nrow = timestep, ncol = nsites)
for (i in 2:nrow(leafNdemand)) {
  leafNdemand[i] <- (input$aglivn[i]) - (input$aglivn[i-1])
}
leafNdemand[leafNdemand < 0] <- 0
# 2026-08-14 SW: 1 site -- second column removed (leafNdemand[,2] <- leafNdemand[,1])


## Calculate NPP
NPP <- daily_NPP 

## Calculate total N demand
totalNdemand <- rootNdemand + leafNdemand

## Calculate plantCN
plantCN <- NPP/totalNdemand
plantCN[is.nan(plantCN)] = 0
plantCN[plantCN == Inf] = 0

## Replenish N stores during senescence
storageNdemand <- matrix(0, nrow = length(NPP), ncol = nsites)

storageNdemand <- vector()
for (i in 1:length(input$yr)){
  if (input$last[i] == 1 && input$harv[i] == 0){
    storageNdemand[i] <- input$aglivn[i-1] * 0.7
  } else storageNdemand[i] <- 0
}

##Calculate leaf N available for retranslocation and the amount of C in litter
## Litter production values also used in CORPSE model for initial litter inputs
## If you have a harvest, remove, else retranslocatable N is N pool on last growth day
leafN <- matrix(0, nrow = length(input$aglivc), ncol = 4)
leafN[,1] <- input$last
leafN[,2] <- input$harv
leafN[,3] <- input$aglivn
for (i in 1:length(leafN[,1])){
  if (leafN[i,2] == 1){
    leafN[i,4] <- leafN[i-1,3] * (1 - input$harvremov[i])  # need a nonzero value
  }  else if (leafN[i,1] == 1){
    leafN[i,4] <- leafN[i-1,3]
  } 
} 

# Calculate litter production if there is harvest
# This calculates harvest differently for annuals (input$lifehist = 0) and perennials (input$lifehist = 1)

litter_production_c <- vector()
litter_production_n <- vector()
litter_production_c <- agrd_turnover_c
litter_production_n <- agrd_turnover_n

# harvest 
# harvest is OFF for spinup
# why is the agrd_turnover_c/n scaled by 0.15? shouldn't it be 0.85? - eddie
# for (i in 1:length(input[,1])) {
#   if (input$harv[i] == 1 & input$lifehist[i] == 0){ # annual harvest
#     litter_production_c[i] <- litter_production_c[i] * (1 - input$harvremov[i])
#     litter_production_n[i] <- litter_production_n[i] * (1 - input$harvremov[i])
#   } 
#   else if (input$lifehist[i] == 1){ # perennial harvest occurs early in year so reduces entire litter
#     litter_production_c[i] <- agrd_turnover_c[i]*0.15
#     litter_production_n[i] <- agrd_turnover_n[i]*0.15
#   }
# }

##Initialize the N and C storage pools. The N is used to grow leaves in Spring.
##Also determine demand in the Fall and C is used for retranslocation

CORPSEstorageN <- vector()
storageC <- vector()

CORPSEstorageN <- storageNdemand  

# do not mess with this (it's retranslocation, PIA)
leafCN_frame <- input[,c("yr", "doy", "aglivc", "aglivn", "last")]
for (i in 1:length(leafCN_frame[,"aglivc"])){
  if (leafCN_frame[i,"last"] == 1 & leafCN_frame[i, "aglivc"] == 0){
    leafCN_frame[i,"aglivc"] <- leafCN_frame[i-1,"aglivc"]
    leafCN_frame[i,"aglivn"] <- leafCN_frame[i-1,"aglivn"]
  } 
}

leafCN <- leafCN_frame$aglivc/leafCN_frame$aglivn #SJ and CW edited, used to be: input$aglivc[i]/input$aglivn[i]

storageC <- storageNdemand * leafCN #assuming that the storage pool of C is equal to the leaf litter C pool

### Create matrices for FUN model outputs 
# most are empty, except cost_storage which is filled with baseline value of 2.0e-3 

# will need to add values for the rhizo and fungal prod for each depth

Npassive <- matrix(0,nrow=timestep,ncol=nsites) ##(kg N/m2/timestep) amount of N taken up through passive uptake
free <- matrix(0,nrow=timestep,ncol=nsites)
storageNmob <- matrix(0,nrow=timestep,ncol=nsites)
FUNstorageN <- matrix(0,nrow=timestep+1,ncol=nsites)
FUNstorageN[,1] <- c(0,CORPSEstorageN)
# 2026-08-14 SW: 1 site -- second column removed
cost_active <- matrix(0,nrow=timestep,ncol=nsites) ##(kg N/m2/timestep) cost of active N uptake
cost_fix <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) cost of N fixation
cost_resorb <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) cost of resorption of leaf N
cost_non_myco <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) cost of non-mycorrhizal active N uptake
cost_acq <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) minimum of cost 1) fixation, 2) active, 3) resorb
rec_cost_acq <- matrix(0,nrow=timestep,ncol=nsites)
Cgrowth <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) C available for NPP and growth
Cgrowth <- NPP  ##First column Cgrowth=NPPmyco
Cacq <- matrix(0,nrow=timestep,ncol=nsites) ##(kg C/m2/timestep) C expended on N uptake
Nacq <- matrix(0,nrow=timestep,ncol=nsites) ##(kg N/m2/timestep) Total N taken up
Cavailable <- matrix(0,nrow=timestep,ncol=nsites)
Cavailable <- NPP ##C available to expend to growth or N uptake
rsoilN <- matrix(0,nrow=timestep,ncol=nsites) ##soilN remaining after passive uptake
Ndeficit <- matrix(0,nrow=timestep,ncol=nsites) ##N uptake needed to meet N demand
total_Nacq <- matrix(0,nrow=timestep,ncol=nsites) 
total_Cgrowth <- matrix(0,nrow=timestep,ncol=nsites)
total_Nacq_active <- matrix(0,nrow=timestep,ncol=nsites) 
total_Nacq_resorb <- matrix(0,nrow=timestep,ncol=nsites)
total_Nacq_fix <- matrix(0,nrow=timestep,ncol=nsites)
total_Nacq_non_myco <- matrix(0,nrow=timestep,ncol=nsites)
total_Nacq_storage <- matrix(0,nrow=timestep,ncol=nsites)
litter_productionN <- matrix(0,nrow=timestep,ncol=nsites)
litter_productionCN <- matrix(0,nrow=timestep,ncol=nsites)
rhizoC_flux <- matrix(0,nrow=timestep,ncol=nsites)
fungal_prod <- matrix(0,nrow=timestep,ncol=nsites)
Ndemand_plus_storage <- matrix(0,nrow=timestep,ncol=nsites)
NPP_plus_storage <- matrix(0,nrow=timestep,ncol=nsites)
resorbper <- matrix(0,nrow=1,ncol=nsites)
cost_storage <- matrix(2.0e-3,nrow=timestep,ncol=nsites)
FUN_shared_inorganicN <- matrix(0,nrow=timestep,ncol=nsites)
total_soil_N_uptake <- matrix(0,nrow=timestep,ncol=nsites)
N_uptakescaler <- matrix(0,nrow=timestep,ncol=nsites)
Nacq_scaler <- matrix(0,nrow=timestep,ncol=nsites)


# run model ----

## model code
## loop needs to happen for nyears for all sites
# i = 1 ; j = 1 ; k = 1
# i is timesteps 
#
# k is doy

start.time <- Sys.time() 


# 2026-08-21 SW FAST: HOIST THE INPUT COLUMNS OUT OF THE LOOP
# ---------------------------------------------------------------------------
# input is a data.frame, so every input$col[i] inside the loop goes through
# [.data.frame -- 22 lookups per timestep, 13.7 percent of loop time, and
# 4x slower than indexing a plain numeric vector. The columns are pulled out
# once here; the loop body reads in_<col>[i] instead.
#
# max(input$nyr) is hoisted for a different and much larger reason: it was
# evaluated TWICE PER TIMESTEP in the progress bar, scanning all 547500 rows
# each time. At 805 us per call that is about 881 s -- 15 minutes -- of a
# 1500 year spin up spent computing a constant. It does not show up in a
# short test run, where the same call costs 3 us.
in_doy <- input$doy
in_nyr <- input$nyr
in_rhizo_frac <- input$rhizo_frac
in_leaf_litter_fastfrac <- input$leaf_litter_fastfrac
in_root_litter_fastfrac <- input$root_litter_fastfrac
in_omad <- input$omad
in_omadc <- input$omadc
in_cult <- input$cult
in_cultrhizmix <- input$cultrhizmix
in_cultlitmix <- input$cultlitmix
in_fert <- input$fert
in_fertamt <- input$fertamt
n_yr_total <- max( input$nyr )

for (i in 1:timestep) {
  
  # # # # # # # # # # # # # # # #
  # Model progress
  # percent <- 100 * ( (i / 365) / n_yr_total )
  # filled <- floor( percent / 10 ) 
  # less <- floor( filled - 1 ) 
  # empty <-  10 - filled 
  # bar <- cat( " " , rep( "🌾" , times = empty ) ,   rep( "🚜" , times = 1 )  , rep( "🌽" , times = if( less < 0 ) { 0 } else { less }  ) ,  " "  )
  # cat("\r d",  in_doy[i] , "  yr" , in_nyr[i] , "/", n_yr_total , bar )
  # # # # # # # # # # # # # # # # #
  
  ##Start CORPSE model main loop
  
  #Parse step into DOY 
  ##this takes the timestep and makes it into DOY
  k <- ((i-1)%%365)+1 # k is DOY
  
  ##Get Temperature and theta (soil moisture) values for this time point
  # Soil temp and VWC have code for either using the same year of data for every year the model is     
  # run, or having data for every day of the simulation (not one year of values that is repeated)
  T_step <- soilT[k]+273.15 # code to use 1 year of data repeatedly
  #T_step <- soilT[i]+273.15 # code for data for every day of the run
  theta_step<-soilVWC[k,1]/porosity # code to use 1 year of data repeatedly
  #theta_step <- soilVWC[i,1]/porosity # code for data for every day of the run
  
  ##Running the CORPSE function 
  
  # units of kg change per year
  # 30
  bulk30[, "inorganicN"] <- shared_inorganicN30
  results_bulk30 <- CORPSE(bulk30, T_step, theta_step, params, claymod, Litter=FALSE)
  shared_inorganicN30 <- shared_inorganicN30 + CORPSEstep * results_bulk30[, "inorganicN"]
  
  rhizo30[, "inorganicN"] <- shared_inorganicN30
  results_rhizo30 <- CORPSE(rhizo30 , T_step, theta_step, params, claymod, Litter=FALSE)
  shared_inorganicN30 <- shared_inorganicN30 + CORPSEstep * results_rhizo30[, "inorganicN"]
  
  litter30[, "inorganicN"] <- shared_inorganicN30
  results_litter30 <- CORPSE(litter30 , T_step, theta_step, params_litter, claymod, Litter=TRUE)
  shared_inorganicN30 <- shared_inorganicN30 + CORPSEstep * results_litter30[, "inorganicN"]
  
  bulk30_till[, "inorganicN"] <- shared_inorganicN30
  results_bulk30_till <- CORPSE( bulk30_till , T_step, theta_step, params, claymod, Litter=FALSE)
  shared_inorganicN30 <- shared_inorganicN30 + CORPSEstep*results_bulk30_till[, "inorganicN"]
  
  rhizo30_till[, "inorganicN"] <- shared_inorganicN30
  results_rhizo30_till <- CORPSE(rhizo30_till , T_step, theta_step, params, claymod, Litter=FALSE)
  shared_inorganicN30 <- shared_inorganicN30+CORPSEstep*results_rhizo30_till[, "inorganicN"]

  # 50 
  bulk50[, "inorganicN"] <- shared_inorganicN50
  results_bulk50 <- CORPSE(bulk50, T_step, theta_step, params50, claymod, Litter=FALSE)
  shared_inorganicN50 <- shared_inorganicN50 + CORPSEstep * results_bulk50[, "inorganicN"]
  
  rhizo50[, "inorganicN"] <- shared_inorganicN50
  results_rhizo50 <- CORPSE(rhizo50, T_step, theta_step, params50, claymod, Litter=FALSE)
  shared_inorganicN50 <- shared_inorganicN50 + CORPSEstep * results_rhizo50[, "inorganicN"]
  
  # 70 
  bulk70[, "inorganicN"] <- shared_inorganicN70
  results_bulk70 <- CORPSE( bulk70 , T_step , theta_step , params70 , claymod , Litter=FALSE )
  shared_inorganicN70 <- shared_inorganicN70 + CORPSEstep * results_bulk70[, "inorganicN"]
  
  rhizo70[, "inorganicN"] <- shared_inorganicN70
  results_rhizo70 <- CORPSE(rhizo70, T_step, theta_step, params70, claymod, Litter=FALSE)
  shared_inorganicN70 <- shared_inorganicN70 + CORPSEstep * results_rhizo70[, "inorganicN"]
  
  # 100 
  bulk100[, "inorganicN"] <- shared_inorganicN100
  results_bulk100 <- CORPSE( bulk100 , T_step , theta_step , params100 , claymod , Litter=FALSE )
  shared_inorganicN100 <- shared_inorganicN100 + CORPSEstep * results_bulk100[, "inorganicN"]
  
  rhizo100[, "inorganicN"] <- shared_inorganicN100
  results_rhizo100 <- CORPSE( rhizo100, T_step, theta_step, params100, claymod, Litter=FALSE)
  shared_inorganicN100 <- shared_inorganicN100 + CORPSEstep * results_rhizo100[, "inorganicN"]
  
  ##Update shared inorganic N pool for each layer to take into account inputs (inorg_Ndep) and outputs for inorganic N removal (from plant roots, leaching, etc)
  ##Record mineralization and immobilization from rates of N pools by timestep
  
  #Add and subtract all changes from shared inorganic N pool
  # iN_loss_rate is the leaching of inorganic N
  # inorg_Ndep only gets added to the top layer of the soil
  
  # 30
  shared_inorganicN30 <- 
    shared_inorganicN30 + CORPSEstep * ( inorg_Ndep - params$iN_loss_rate * shared_inorganicN30 )
  
  # 50
  # 2026-08-14 SW: each donation now uses the DONATING layer's own iN_loss_rate, so
  # the gain below always equals the loss above. Previously every donation
  # used params$iN_loss_rate while the losses used params50/70/100$, which
  # is conservative only while all four rates are equal.
  shared_inorganicN50 <- shared_inorganicN50 + CORPSEstep * ( params$iN_loss_rate * shared_inorganicN30 )
    
  shared_inorganicN50 <- 
    shared_inorganicN50 + CORPSEstep *( - params50$iN_loss_rate * shared_inorganicN50)
  
  # 70
  shared_inorganicN70 <- shared_inorganicN70 + CORPSEstep * ( params50$iN_loss_rate * shared_inorganicN50 )
  
  shared_inorganicN70 <- 
    shared_inorganicN70 + CORPSEstep *( - params70$iN_loss_rate * shared_inorganicN70)
  
  # 100
  shared_inorganicN100 <- shared_inorganicN100 + CORPSEstep * ( params70$iN_loss_rate * shared_inorganicN70 )
  
  shared_inorganicN100 <- 
    shared_inorganicN100 + CORPSEstep *( - params100$iN_loss_rate * shared_inorganicN100)
  
  # summing the shared_inorganicN across depth profiles
  shared_inorganicN <- 
    shared_inorganicN30 + 
    shared_inorganicN50 + 
    shared_inorganicN70 +
    shared_inorganicN100
  
  ##model will stop if shared inorganic N < 0
  if( min( shared_inorganicN ) < 0 ) { crash( 'Inorganic N < 0' ) }
  
  ## Update the pools in SOM by add derivs * dt ( length of time step ) to each SOM pool.  
  ## This converts the units from mass per year to mass per the selected time step
  
  # 30 
  # bulk30
  bulk30 <- bulk30 + results_bulk30*CORPSEstep
  bulk30[, "inorganicN"] <- shared_inorganicN30
  if(min(bulk30)<0) {crash('Value is bulk30 < 0')}
  
  # rhizo30
  rhizo30 <- rhizo30 + results_rhizo30*CORPSEstep
  rhizo30[, "inorganicN"] <- shared_inorganicN30
  if(min(rhizo30)<0) {crash('Value is rhizo30 < 0')}
  
  # litter30
  litter30 <- litter30 + results_litter30*CORPSEstep
  litter30[, "inorganicN"] <- shared_inorganicN30
  if(min(litter30)<0) {crash('Value is litter < 0')}
  
  # bulk30_till
  bulk30_till <- bulk30_till + results_bulk30_till*CORPSEstep
  bulk30_till[, "inorganicN"] <- shared_inorganicN30
  if(min(bulk30_till)<0) {crash('Value is bulk_till < 0')}
  
  # rhizo30_till
  rhizo30_till <- rhizo30_till + results_rhizo30_till*CORPSEstep
  rhizo30_till[, "inorganicN"] <- shared_inorganicN30
  if(min(rhizo30_till)<0) {crash('Value is rhizo_till < 0')}
  
  # 50
  # bulk50
  bulk50 <- bulk50 + results_bulk50*CORPSEstep
  bulk50[, "inorganicN"] <- shared_inorganicN50
  if(min(bulk50)<0) {crash('Value is bulk50 < 0')}
  
  # rhizo50
  rhizo50 <- rhizo50 + results_rhizo50*CORPSEstep
  rhizo50[, "inorganicN"] <- shared_inorganicN50
  if(min(rhizo50)<0) {crash('Value is rhizo50 < 0')}
  
  # 70
  # bulk70
  bulk70 <- bulk70 + results_bulk70*CORPSEstep
  bulk70[, "inorganicN"] <- shared_inorganicN70
  if( min( bulk70 ) < 0 ) {crash('Value is bulk70 < 0')}
  
  # rhizo70
  rhizo70 <- rhizo70 + results_rhizo70*CORPSEstep
  rhizo70[, "inorganicN"] <- shared_inorganicN70
  if( min( rhizo70 ) < 0 ) {crash('Value is rhizo70 < 0')}
  
  # 100
  # bulk100
  bulk100 <- bulk100 + results_bulk100*CORPSEstep
  bulk100[, "inorganicN"] <- shared_inorganicN100
  if( min( bulk100 ) < 0 ) {crash('Value is bulk100 < 0')}
  
  # rhizo100
  rhizo100 <- rhizo100 + results_rhizo100*CORPSEstep
  rhizo100[, "inorganicN"] <- shared_inorganicN100
  if( min( rhizo100 ) < 0 ) {crash('Value is rhizo100 < 0')}
  
  # # print counter in R console
  # if (input$doy[i]==1) print(paste("day", input$doy[i], "of year", input$nyr[i], "of", max(input$nyr), "total years", sep = " "))
  
  # Keep track of latest data
  # 30 
  bulk30_final_list[[i]] <- bulk30
  rhizo30_final_list[[i]] <- rhizo30
  litter30_final_list[[i]] <- litter30
  
  bulk30_till_final_list[[i]] <- bulk30_till
  rhizo30_till_final_list[[i]] <- rhizo30_till

  # 50
  bulk50_final_list[[i]] <- bulk50
  rhizo50_final_list[[i]] <- rhizo50
  
  # 70 
  bulk70_final_list[[i]] <- bulk70
  rhizo70_final_list[[i]] <- rhizo70
  
  # 100 
  bulk100_final_list[[i]] <- bulk100
  rhizo100_final_list[[i]] <- rhizo100
  
  
  ## Given that the rhizosphere is not static (i.e., roots forage) 
  ## there are two processes that need to occur:
  ## 1. The rhizosphere size changes each time step with root biomass
  ## 2. The rhizosphere and bulk soil mix.   
  
  # !Q It doesn't seem like the rhizosphere is dynamic?
  # Calculate change in rhizosphere between time steps
  ## t function transposes data frame
  
  # rhizo_frac needs to be between 0 and 1
  rhizo_frac <- in_rhizo_frac[i]
  
  # 2026-08-14 SW: DEPTH-SPECIFIC RHIZOSPHERE FRACTIONS
  # --------------------------------------------------------------------------
  # rhizo_frac comes from DayCent and describes the 0-30 cm layer only: it is
  # the fraction of THAT layer's soil which is rhizosphere. This model extends
  # below the depth DayCent simulates, so the rhizosphere fraction of each
  # subsoil layer has to be predicted, assuming rhizosphere size is
  # proportional to root biomass. root_pool_scale_* already holds exactly that
  # proportion (root biomass in each layer relative to 0-30 cm), so it is
  # reused here rather than defining a second, numerically identical scalar.
  # If the two assumptions ever need to diverge -- rhizosphere volume scaling
  # with depth differently from root mass -- split them into separate vectors
  # at that point.
  #
  # These are WITHIN-layer partition terms ONLY. (1 - rhizo_frac_XX) and
  # rhizo_frac_XX sum to 1, so they never change a layer's total. Between-layer
  # allocation of plant C and N is separate: the flux is multiplied by
  # root_pool_scale_XX OUTSIDE the partition.
  rhizo_frac_30  <- rhizo_frac * root_pool_scale_30
  rhizo_frac_50  <- rhizo_frac * root_pool_scale_50
  rhizo_frac_70  <- rhizo_frac * root_pool_scale_70
  rhizo_frac_100 <- rhizo_frac * root_pool_scale_100
  
  if ( any( c( rhizo_frac_30, rhizo_frac_50, rhizo_frac_70, rhizo_frac_100 ) < 0 ) |
       any( c( rhizo_frac_30, rhizo_frac_50, rhizo_frac_70, rhizo_frac_100 ) > 1 ) ) {
    crash('a depth-specific rhizo_frac is outside [0,1]')
  }
  
  
  ## CORPSE calculates cumulative CO2 release. This code keeps track of CO2 from each soil pool so that it is maintained when the soils are mixed.  Further down the code the CO2 is reassigned to its individual layers.
  # 30 
  CO2_bulk30 <- bulk30[, "CO2"]
  CO2_rhizo30 <- rhizo30[, "CO2"]
  CO2_litter30 <- litter30[, "CO2"]
  CO2_bulk30_till <- bulk30_till[, "CO2"] 
  CO2_rhizo30_till <- rhizo30_till[, "CO2"]
  
  # 50
  CO2_bulk50 <- bulk50[, "CO2"] 
  CO2_rhizo50 <- rhizo50[, "CO2"]
  
  # 70
  CO2_bulk70 <- bulk70[, "CO2"] 
  CO2_rhizo70 <- rhizo70[, "CO2"]
  
  # 100
  CO2_bulk100 <- bulk100[, "CO2"] 
  CO2_rhizo100 <- rhizo100[, "CO2"]
  
  
  ## Mix bulk soil and rhizo soil together daily using froot_turnover_fraction (= 1/365)
  # calculate a daily portion of each soil compartment
  
  # maybe we could just use the rhizofrac to calculate the mixing effect
  # of soils going from the rhizosphere to bulk soil
  # 30 
  soilMix_bulk30 <- froot_turnover_fraction * bulk30
  soilMix_rhizo30 <- froot_turnover_fraction * rhizo30
  soilMix_bulk30_till <- froot_turnover_fraction * bulk30_till
  soilMix_rhizo30_till <- froot_turnover_fraction * rhizo30_till
  
   # 50
  soilMix_bulk50 <- froot_turnover_fraction * bulk50
  soilMix_rhizo50 <- froot_turnover_fraction * rhizo50
  
  # 70
  soilMix_bulk70 <- froot_turnover_fraction * bulk70
  soilMix_rhizo70 <- froot_turnover_fraction * rhizo70
  
  # 100
  soilMix_bulk100 <- froot_turnover_fraction * bulk100
  soilMix_rhizo100 <- froot_turnover_fraction * rhizo100
  
  # add together the bulk and rhizo soil allocated for mixing (by tilled and non-tilled)
  # 30 
  soilMix30 <- soilMix_bulk30 + soilMix_rhizo30
  soilMix30_till <- soilMix_bulk30_till + soilMix_rhizo30_till
  
  # 50 
  soilMix50 <- soilMix_bulk50 + soilMix_rhizo50
  
  # 70 
  soilMix70 <- soilMix_bulk70 + soilMix_rhizo70
  
  # 100 
  soilMix100 <- soilMix_bulk100 + soilMix_rhizo100

  # subtract the soil allocated for mixing (calculated above) from the compartments
  # 30 
  bulk30 <- bulk30 - soilMix_bulk30
  rhizo30 <- rhizo30 - soilMix_rhizo30
  
  bulk30_till <- bulk30_till - soilMix_bulk30_till
  rhizo30_till <- rhizo30_till - soilMix_rhizo30_till
  
  # 50
  bulk50 <- bulk50 - soilMix_bulk50
  rhizo50 <- rhizo50 - soilMix_rhizo50
  
  # 70
  bulk70 <- bulk70 - soilMix_bulk70
  rhizo70 <- rhizo70 - soilMix_rhizo70
  
  # 100
  bulk100 <- bulk100 - soilMix_bulk100
  rhizo100 <- rhizo100 - soilMix_rhizo100

  # add a portion (set by rhizo-frac) of the mixed soil back into the compartments
  # 30 
  # 2026-08-14 SW: root_pool_scale_* removed from all four blocks below.
  # Mixing is a WITHIN-layer redistribution: the soil removed above
  # (soilMixXX) must be returned in full, split between bulk and rhizosphere
  # by rhizo_frac alone -- the two fractions already sum to 1.
  # Multiplying the returned portion by a depth weight destroyed
  # (1 - root_pool_scale_XX) of the mixed soil every timestep, i.e. roughly
  # 58 / 61 / 62 percent of layer C per year at 50 / 70 / 100 cm.
  # Depth weighting belongs only on the plant input fluxes (root turnover,
  # fungal production, exudates), where it is applied correctly further down.
  bulk30 <- bulk30 + ( soilMix30 * ( 1.0 - rhizo_frac_30 ) )
  rhizo30 <- rhizo30 + ( soilMix30 * ( rhizo_frac_30 ) )
  bulk30_till <- bulk30_till + (soilMix30_till * ( 1.0 - rhizo_frac_30 ) )
  rhizo30_till <- rhizo30_till + (soilMix30_till * ( rhizo_frac_30 ) )
  
  # 50
  bulk50 <- bulk50 + (soilMix50 * (1.0 - rhizo_frac_50 ) )
  rhizo50 <- rhizo50 + (soilMix50 * (rhizo_frac_50 ) )
  
  # 70
  bulk70 <- bulk70 + (soilMix70 * (1.0 - rhizo_frac_70 ) )
  rhizo70 <- rhizo70 + (soilMix70 * (rhizo_frac_70 ) )
  
  # 100
  bulk100 <- bulk100 + (soilMix100 * (1.0 - rhizo_frac_100 ) )
  rhizo100 <- rhizo100 + (soilMix100 * (rhizo_frac_100 ))
  
  
  ##Add leaf litter inputs to litter layer 
  # fastfrac changes with crop type, and by leaf/root litter
  leaf_litter_fastfrac <- in_leaf_litter_fastfrac[i]
  litter30[, "uFastC"] <- litter30[, "uFastC"]+(litter_production_c[i]*leaf_litter_fastfrac)
  litter30[, "uSlowC"] <- litter30[, "uSlowC"]+(litter_production_c[i]*(1-leaf_litter_fastfrac))
  litter30[, "uFastN"] <- litter30[, "uFastN"]+((litter_production_n[i]*leaf_litter_fastfrac))
  litter30[, "uSlowN"] <- litter30[, "uSlowN"]+((litter_production_n[i]*(1-leaf_litter_fastfrac)))
  
  ##Add root litter inputs to the rhizosphere and bulk soil layers
  # some C and N into fast and slow C/N depending on the fastfrac number
  # keep in mind that tillage is restricted to the top 30
  # for depths below 30, scaling the rhizosphere size by the fraction of roots at that DI
  root_litter_fastfrac <- in_root_litter_fastfrac[i]
  
  # C 
  # 30
  # C bulk30
  bulk30[, "uFastC"] <-
    bulk30[, "uFastC"] + ( froot_turnover_c[i] * ( 1 - pct_soil_tilled ) * root_litter_fastfrac * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  bulk30[, "uSlowC"] <-
    bulk30[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - pct_soil_tilled ) * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30

  # C rhizo30
  rhizo30[, "uFastC"] <-
    rhizo30[, "uFastC"] + ( froot_turnover_c[i] * ( 1 - pct_soil_tilled ) * root_litter_fastfrac * rhizo_frac_30 ) * root_pool_scale_30
  rhizo30[, "uSlowC"] <-
    rhizo30[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - pct_soil_tilled ) * ( 1 - root_litter_fastfrac ) * rhizo_frac_30 ) * root_pool_scale_30
  
  # C bulk30 till
  bulk30_till[, "uFastC"] <-
    bulk30_till[, "uFastC"] + ( froot_turnover_c[i] * pct_soil_tilled * root_litter_fastfrac * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  bulk30_till[, "uSlowC"] <-
    bulk30_till[, "uSlowC"] + ( froot_turnover_c[i] * pct_soil_tilled * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  
  # C rhizo30 till
  rhizo30_till[, "uFastC"] <-
    rhizo30_till[, "uFastC"] + ( froot_turnover_c[i] * pct_soil_tilled * root_litter_fastfrac * rhizo_frac_30 ) * root_pool_scale_30
  rhizo30_till[, "uSlowC"] <-
    rhizo30_till[, "uSlowC"] + ( froot_turnover_c[i] * pct_soil_tilled * ( 1 - root_litter_fastfrac ) * rhizo_frac_30 ) * root_pool_scale_30

  # 50
  # C bulk50
  bulk50[, "uFastC"] <-
    bulk50[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * ( 1 - rhizo_frac_50 ) ) * root_pool_scale_50
  bulk50[, "uSlowC"] <-
    bulk50[, "uSlowC"]+( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_50 ) ) * root_pool_scale_50
  
  # C rhizo50
  rhizo50[, "uFastC"] <-
    rhizo50[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * rhizo_frac_50 )* root_pool_scale_50
  rhizo50[, "uSlowC"] <-
    rhizo50[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_50  )* root_pool_scale_50
  
  # 70
  # C bulk70
  bulk70[, "uFastC"] <-
    bulk70[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * ( 1 - rhizo_frac_70 ) ) * root_pool_scale_70
  bulk70[, "uSlowC"] <-
    bulk70[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_70 ) ) * root_pool_scale_70
  
  # C rhizo70
  rhizo70[, "uFastC"] <-
    rhizo70[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * rhizo_frac_70 ) * root_pool_scale_70
  rhizo70[, "uSlowC"] <-
    rhizo70[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_70 ) * root_pool_scale_70
  
  # 100
  # C bulk100
  bulk100[, "uFastC"] <-
    bulk100[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * ( 1 - rhizo_frac_100 ) ) * root_pool_scale_100
  bulk100[, "uSlowC"] <-
    bulk100[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_100 ) ) * root_pool_scale_100
  
  # C rhizo100
  rhizo100[, "uFastC"] <-
    rhizo100[, "uFastC"] + ( froot_turnover_c[i] * root_litter_fastfrac * rhizo_frac_100 ) * root_pool_scale_100
  rhizo100[, "uSlowC"] <-
    rhizo100[, "uSlowC"] + ( froot_turnover_c[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_100  ) * root_pool_scale_100
  
  root_turnover_per_depth[i, ] <- froot_turnover_c[i] *
    c( root_pool_scale_30 , root_pool_scale_50 , root_pool_scale_70 , root_pool_scale_100 )
  
  # N
  # 30 
  # bulk30
  bulk30[, "uFastN"] <-
    bulk30[, "uFastN"] + ( froot_turnover_n[i] * ( 1 - pct_soil_tilled ) * root_litter_fastfrac * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  bulk30[, "uSlowN"] <-
    bulk30[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - pct_soil_tilled ) * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  
  # rhizo30 
  rhizo30[, "uFastN"] <-
    rhizo30[, "uFastN"] + ( froot_turnover_n[i] * ( 1 - pct_soil_tilled ) * root_litter_fastfrac * rhizo_frac_30 ) * root_pool_scale_30
  rhizo30[, "uSlowN"] <-
    rhizo30[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - pct_soil_tilled ) * ( 1 - root_litter_fastfrac ) * rhizo_frac_30 ) * root_pool_scale_30
  
  # bulk30_till
  bulk30_till[, "uFastN"] <-
    bulk30_till[, "uFastN"] + ( froot_turnover_n[i] * pct_soil_tilled * root_litter_fastfrac * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  bulk30_till[, "uSlowN"] <-
    bulk30_till[, "uSlowN"] + ( froot_turnover_n[i] * pct_soil_tilled * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_30 ) ) * root_pool_scale_30
  
  # N rhizo30_till
  rhizo30_till[, "uFastN"] <-
    rhizo30_till[, "uFastN"] + ( froot_turnover_n[i] * pct_soil_tilled * root_litter_fastfrac * rhizo_frac_30 ) * root_pool_scale_30
  rhizo30_till[, "uSlowN"] <-
    rhizo30_till[, "uSlowN"] + ( froot_turnover_n[i] * pct_soil_tilled * ( 1 - root_litter_fastfrac ) * rhizo_frac_30 ) * root_pool_scale_30
  
  # 50 
  # N bulk50
  bulk50[, "uFastN"] <-
    bulk50[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * ( 1 - rhizo_frac_50 ) ) * root_pool_scale_50 
  bulk50[, "uSlowN"] <-
    bulk50[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_50 ) ) * root_pool_scale_50
  
  # N rhizo50
  rhizo50[, "uFastN"] <-
    rhizo50[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * rhizo_frac_50 ) * root_pool_scale_50
  rhizo50[, "uSlowN"] <-
    rhizo50[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_50 ) * root_pool_scale_50 
  
  # 70
  # N bulk70
  bulk70[, "uFastN"] <-
    bulk70[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * ( 1 - rhizo_frac_70 ) ) *  root_pool_scale_70 
  bulk70[, "uSlowN"] <- 
    bulk70[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_70  ) ) * root_pool_scale_70
  
  # N rhizo70
  rhizo70[, "uFastN"] <- 
    rhizo70[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * rhizo_frac_70  ) * root_pool_scale_70
  rhizo70[, "uSlowN"] <-
    rhizo70[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_70  ) * root_pool_scale_70
  
  # 100
  # N bulk100
  bulk100[, "uFastN"] <-
    bulk100[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * ( 1 - rhizo_frac_100 ) ) * root_pool_scale_100
  bulk100[, "uSlowN"] <- 
    bulk100[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * ( 1 - rhizo_frac_100 ) )  * root_pool_scale_100 
  
  # N rhizo100
  rhizo100[, "uFastN"] <- 
    rhizo100[, "uFastN"] + ( froot_turnover_n[i] * root_litter_fastfrac * rhizo_frac_100) * root_pool_scale_100 
  rhizo100[, "uSlowN"] <-
    rhizo100[, "uSlowN"] + ( froot_turnover_n[i] * ( 1 - root_litter_fastfrac ) * rhizo_frac_100 ) * root_pool_scale_100 
  
  ## Transfer a portion of the litter layer to the bulk and rhizosphere each time step
  # litter transfer to soil happens only in top 30
  # calculate a daily portion (1/365) of the litter layer

  newsoil <- litter30 * litter_transfer_to_soil
  
  # subtract the mixed portion from the litter layer
  litter30 <- litter30 - (litter30 * litter_transfer_to_soil)
  
  # Divide newsoil into bulk/rhizo and tilled/untilled by pct_soil_tilled and rhizo_frac 
  # 30 
  bulk30 <- bulk30 + ( newsoil * ( 1 - pct_soil_tilled ) * ( 1 - rhizo_frac_30 ) )
  rhizo30 <- rhizo30 + ( newsoil * ( 1 - pct_soil_tilled ) * ( rhizo_frac_30 ) )
  bulk30_till <- bulk30_till + ( newsoil * pct_soil_tilled * ( 1 - rhizo_frac_30 ) )
  rhizo30_till <- rhizo30_till + ( newsoil * pct_soil_tilled * rhizo_frac_30 )
  
  
  ###Add fungal production to bulk and rhizo layers (C spent on mycorrhizal uptake in FUN)
  
  # add in splits for the different depths
  # scaling fungal production by the rhizosphere size 
  # which is scaled currently by froot_scale_** (from Zoe Pagliaro)
      # In the future we can scale by the N pool if we model depth specific N cycling

  # generic to make calculation easier
  # 30
  fungal_prod_bulk_till <- fungal_prod[i,] * ( pct_soil_tilled ) * ( 1 - rhizo_frac_30 ) * root_pool_scale_30
  fungal_prod_rhizo_till <- fungal_prod[i,] * ( pct_soil_tilled ) * rhizo_frac_30 * root_pool_scale_30
  
  fungal_prod_bulk <- fungal_prod[i,] * ( 1 - pct_soil_tilled ) * ( 1 - rhizo_frac_30 ) * root_pool_scale_30
  fungal_prod_rhizo <- fungal_prod[i,] * ( 1 - pct_soil_tilled ) * rhizo_frac_30 * root_pool_scale_30
  
  # 50
  fungal_prod_bulk50 <- fungal_prod[i,] * ( 1 - rhizo_frac_50 )  * root_pool_scale_50
  fungal_prod_rhizo50 <- fungal_prod[i,] * rhizo_frac_50 * root_pool_scale_50 

  # 70
  fungal_prod_bulk70 <- fungal_prod[i,] * ( 1 - rhizo_frac_70 )  * root_pool_scale_70
  fungal_prod_rhizo70 <- fungal_prod[i,]  * rhizo_frac_70 * root_pool_scale_70 
  
  # 100 
  fungal_prod_bulk100 <- fungal_prod[i,]  * ( 1 - rhizo_frac_100 ) * root_pool_scale_100 
  fungal_prod_rhizo100 <- fungal_prod[i,]  * rhizo_frac_100 * root_pool_scale_100 
  
  
  fungal_prod_per_depth[i, ] <- c(
    fungal_prod_bulk_till + fungal_prod_rhizo_till + fungal_prod_bulk + fungal_prod_rhizo ,
    fungal_prod_bulk50  + fungal_prod_rhizo50  ,
    fungal_prod_bulk70  + fungal_prod_rhizo70  ,
    fungal_prod_bulk100 + fungal_prod_rhizo100 )
  
  ## FastC
  # 30 
  bulk30[, "uFastC"] <- bulk30[, "uFastC"] + fungal_prod_bulk
  rhizo30[, "uFastC"] <- rhizo30[, "uFastC"] + fungal_prod_rhizo
  
  # till layer
  bulk30_till[, "uFastC"] <- bulk30_till[, "uFastC"] + fungal_prod_bulk_till 
  rhizo30_till[, "uFastC"] <- rhizo30_till[, "uFastC"] + fungal_prod_rhizo_till
  
  # 50
  # note, this is scaled by the fraction of roots in depth 31 - 50 ( root_pool_scale_50 )
  bulk50[, "uFastC"] <- bulk50[, "uFastC"] + fungal_prod_bulk50
  rhizo50[, "uFastC"] <- rhizo50[, "uFastC"] + fungal_prod_rhizo50
  
  # 70
  # note, this is scaled by the fraction of roots in depth 51-70 ( root_pool_scale_70 )
  bulk70[, "uFastC"] <- bulk70[, "uFastC"] + fungal_prod_bulk70
  rhizo70[, "uFastC"] <- rhizo70[, "uFastC"] + fungal_prod_rhizo70
  
  # 100
  # note, this is scaled by the fraction of roots in depth 71-100 ( root_pool_scale_100 )
  bulk100[, "uFastC"] <- bulk100[, "uFastC"] + fungal_prod_bulk100
  rhizo100[, "uFastC"] <- rhizo100[, "uFastC"] + fungal_prod_rhizo100
  
  # FastN 
  # 30
  bulk30[, "uFastN"] <- bulk30[, "uFastN"] + ( fungal_prod_bulk / exudate_CN )

  rhizo30[, "uFastN"] <- rhizo30[, "uFastN"] + ( fungal_prod_rhizo / exudate_CN )
  
  # till
  bulk30_till[, "uFastN"] <- bulk30_till[, "uFastN"] + ( fungal_prod_bulk_till / exudate_CN )
  
  rhizo30_till[, "uFastN"] <- rhizo30_till[, "uFastN"] + ( fungal_prod_rhizo_till / exudate_CN )
 
  # 50
  # note, this is scaled by the fraction of roots in depth 31 - 50 ( root_pool_scale_50 )
  bulk50[, "uFastN"] <-
    bulk50[, "uFastN"] + ( fungal_prod_bulk50 / exudate_CN )
  rhizo50[, "uFastN"] <-
    rhizo50[, "uFastN"] + ( fungal_prod_rhizo50 / exudate_CN ) 
  
  # 70 
  # note, this is scaled by the fraction of roots in depth 51-70 ( root_pool_scale_70 )
  bulk70[, "uFastN"] <-
    bulk70[, "uFastN"] + ( fungal_prod_bulk70 / exudate_CN ) 
  rhizo70[, "uFastN"] <-
    rhizo70[, "uFastN"] + ( fungal_prod_rhizo70 / exudate_CN )
  
  # 100 
  # note, this is scaled by the fraction of roots in depth 71-100 ( root_pool_scale_100 )
  bulk100[, "uFastN"] <-
    bulk100[, "uFastN"] + ( fungal_prod_bulk100 / exudate_CN )
  rhizo100[, "uFastN"] <-
    rhizo100[, "uFastN"] + ( fungal_prod_rhizo100 / exudate_CN )
  
  ## Root exudation( non-mycorrhizal C flux to rhizosphere )
  # this is constrained to the rhizosphere (rhizo)
  rhizoC_flux2 <- rhizoC_flux[i,]
  # 30
  rhizo30[, "uFastC"] <- rhizo30[, "uFastC"] + rhizoC_flux[i,] * (1 - pct_soil_tilled) * root_pool_scale_30
  rhizo30_till[, "uFastC"] <- rhizo30_till[, "uFastC"] + rhizoC_flux[i,] * pct_soil_tilled * root_pool_scale_30
  
  # 50
  # note, the amount of C flowing to the labile C (uFastC) pool from roots is 
  # scaled by the proportion of roots in 31-50 cm deep relative to 0-30 cm 
  
  rhizo50[, "uFastC"] <- rhizo50[, "uFastC"] + rhizoC_flux[i,]  * root_pool_scale_50
  
  # 70
  rhizo70[, "uFastC"] <- rhizo70[, "uFastC"] + rhizoC_flux[i,]  * root_pool_scale_70
  
  # 100
  rhizo100[, "uFastC"] <- rhizo100[, "uFastC"] + rhizoC_flux[i,]  * root_pool_scale_100
  
  root_exude_per_depth[i, ] <- rhizoC_flux[i,] *
    c( root_pool_scale_30 , root_pool_scale_50 , root_pool_scale_70 , root_pool_scale_100 )
  
  # DON/DOC leaching
  # Added 2026-01-27 from Stephanie Juices Deep FUN-BioCROP prairie spinup code
  ## Moving uFastC and uFastN down, just for bulk
  # assign percentages to move down by depth
  
  # DOM leaching declines with depth 
  # with the ASSUMPTION that this will show a similar pattern
  # as root depth distribution
  # given values 2026-03-03 SW
  # 2026-08-14 SW MATRIX: DOMleach constants hoisted above the loop (see below)
  
  # leaching
  # amount = extant amount of + leached from above - leached to below
  
  # 30
  # C
  leached_C30 <- ( bulk30[, "uFastC"] + bulk30_till[, "uFastC"] ) * DOMleach30
  bulk30[, "uFastC"] <-  bulk30[, "uFastC"] * ( 1 - DOMleach30)
  bulk30_till[, "uFastC"] <- bulk30_till[, "uFastC"] * ( 1 - DOMleach30)
  # N
  leached_N30 <- ( bulk30[, "uFastN"] + bulk30_till[, "uFastN"] ) * DOMleach30
  bulk30[, "uFastN"] <-  bulk30[, "uFastN"] * ( 1 - DOMleach30)
  bulk30_till[, "uFastN"] <- bulk30_till[, "uFastN"] * ( 1 - DOMleach30)

  # 50
  # C
  leached_C50 <- bulk50[, "uFastC"] * DOMleach50
  bulk50[, "uFastC"] <- bulk50[, "uFastC"]  + leached_C30 - leached_C50
  # N
  leached_N50 <- bulk50[, "uFastN"] * DOMleach50
  bulk50[, "uFastN"] <- bulk50[, "uFastN"] + leached_N30 - leached_N50
  
  # 70

  leached_C70 <- bulk70[, "uFastC"] * DOMleach70
  bulk70[, "uFastC"] <- bulk70[, "uFastC"]  + leached_C50 - leached_C70
  
  leached_N70 <- bulk70[, "uFastN"] * DOMleach70
  bulk70[, "uFastN"] <- bulk70[, "uFastN"] + leached_N50 - leached_N70
  
  # 100
  leached_C100 <- bulk100[, "uFastC"] * DOMleach100
  bulk100[, "uFastC"] <- bulk100[, "uFastC"]  + leached_C70 - leached_C100
  
  leached_N100 <- bulk100[, "uFastN"] * DOMleach100
  bulk100[, "uFastN"] <- bulk100[, "uFastN"] + leached_N70 - leached_N100
  
  # ORGANIC MATTER ADDITION
  # add to litter layer, lignin fraction to slow pool, everything else to fast pool
  # can copy and paste same code from litter addition
  # can be coded to pull input$omadlig value for 0.5 values
  
  if (in_omad[i] == 1){
    litter30[, "uFastC"] <- litter30[, "uFastC"] + ((in_omadc[i] / 1000) * (1 - 0.5))
    litter30[, "uSlowC"] <- litter30[, "uSlowC"] + ((in_omadc[i] / 1000) * 0.5)
    litter30[, "uFastN"] <- litter30[, "uFastN"] + (((in_omadc[i] / 1000) * (1 - 0.5) / 40))
    litter30[, "uSlowN"] <- litter30[, "uSlowN"] + (((in_omadc[i] / 1000) * 0.5) / 40)
  }
  
  
  # TILLAGE - Moving tillage protectedC to unprotectedC
  
  if (in_cult[i] == 1) {
    # add portion of rhizo30_till to bulk30_till
    rhizo30_till_mix <- rhizo30_till * in_cultrhizmix[i]
    bulk30_till <- bulk30_till + rhizo30_till_mix
    rhizo30_till <- rhizo30_till - rhizo30_till_mix
    # add portion of litter to bulk30_till
    bulk30_till <- bulk30_till + (litter30 * in_cultlitmix[i])
    litter30 <- litter30 * (1 - in_cultlitmix[i])
    
    bulk30_till[, "uFastC"] <- bulk30_till[, "uFastC"] + (bulk30_till[, "pFastC"] * tillPtoUP)
    bulk30_till[, "pFastC"] <- bulk30_till[, "pFastC"] - (bulk30_till[, "pFastC"] * tillPtoUP)
    bulk30_till[, "uFastN"] <- bulk30_till[, "uFastN"] + (bulk30_till[, "pFastN"] * tillPtoUP)
    bulk30_till[, "pFastN"] <- bulk30_till[, "pFastN"] - (bulk30_till[, "pFastN"] * tillPtoUP)
    
    bulk30_till[, "uSlowC"] <- bulk30_till[, "uSlowC"] + (bulk30_till[, "pSlowC"] * tillPtoUP)
    bulk30_till[, "pSlowC"] <- bulk30_till[, "pSlowC"] - (bulk30_till[, "pSlowC"] * tillPtoUP)
    bulk30_till[, "uSlowN"] <- bulk30_till[, "uSlowN"] + (bulk30_till[, "pSlowN"] * tillPtoUP)
    bulk30_till[, "pSlowN"] <- bulk30_till[, "pSlowN"] - (bulk30_till[, "pSlowN"] * tillPtoUP)
    
    bulk30_till[, "uNecroC"] <- bulk30_till[, "uNecroC"] + (bulk30_till[, "pNecroC"] * tillPtoUP)
    bulk30_till[, "pNecroC"] <- bulk30_till[, "pNecroC"] - (bulk30_till[, "pNecroC"] * tillPtoUP)
    bulk30_till[, "uNecroN"] <- bulk30_till[, "uNecroN"] + (bulk30_till[, "pNecroN"] * tillPtoUP)
    bulk30_till[, "pNecroN"] <- bulk30_till[, "pNecroN"] - (bulk30_till[, "pNecroN"] * tillPtoUP)
    
    rhizo30_till[, "uFastC"] <- rhizo30_till[, "uFastC"] + (rhizo30_till[, "pFastC"] * tillPtoUP)
    rhizo30_till[, "pFastC"] <- rhizo30_till[, "pFastC"] - (rhizo30_till[, "pFastC"] * tillPtoUP)
    rhizo30_till[, "uFastN"] <- rhizo30_till[, "uFastN"] + (rhizo30_till[, "pFastN"] * tillPtoUP)
    rhizo30_till[, "pFastN"] <- rhizo30_till[, "pFastN"] - (rhizo30_till[, "pFastN"] * tillPtoUP)
    
    rhizo30_till[, "uSlowC"] <- rhizo30_till[, "uSlowC"] + (rhizo30_till[, "pSlowC"] * tillPtoUP)
    rhizo30_till[, "pSlowC"] <- rhizo30_till[, "pSlowC"] - (rhizo30_till[, "pSlowC"] * tillPtoUP)
    rhizo30_till[, "uSlowN"] <- rhizo30_till[, "uSlowN"] + (rhizo30_till[, "pSlowN"] * tillPtoUP)
    rhizo30_till[, "pSlowN"] <- rhizo30_till[, "pSlowN"] - (rhizo30_till[, "pSlowN"] * tillPtoUP)
    
    rhizo30_till[, "uNecroC"] <- rhizo30_till[, "uNecroC"] + (rhizo30_till[, "pNecroC"] * tillPtoUP)
    rhizo30_till[, "pNecroC"] <- rhizo30_till[, "pNecroC"] - (rhizo30_till[, "pNecroC"] * tillPtoUP)
    rhizo30_till[, "uNecroN"] <- rhizo30_till[, "uNecroN"] + (rhizo30_till[, "pNecroN"] * tillPtoUP)
    rhizo30_till[, "pNecroN"] <- rhizo30_till[, "pNecroN"] - (rhizo30_till[, "pNecroN"] * tillPtoUP)
    
  }
  
  # FERTILIZER
  #add n to shared inorganic n pool
  if (in_fert[i] == 1){
    # !Q Do I need to split things up by depth here? 
    # I seem to remember shared inorganicN for each depth being summed earlier
    shared_inorganicN30 <- shared_inorganicN30 + (in_fertamt[i] / 1000)
  }
  
  # Reassign CO2 values to each pool
  # 30 
  bulk30[, "CO2"] <- CO2_bulk30 
  rhizo30[, "CO2"] <- CO2_rhizo30
  litter30[, "CO2"] <- CO2_litter30
  bulk30_till[, "CO2"] <- CO2_bulk30_till
  rhizo30_till[, "CO2"] <- CO2_rhizo30_till
  
  # 50
  bulk50[, "CO2"] <- CO2_bulk50
  rhizo50[, "CO2"] <- CO2_rhizo50
  
  # 70
  bulk70[, "CO2"] <- CO2_bulk70
  rhizo70[, "CO2"] <- CO2_rhizo70
  
  # 100
  bulk100[, "CO2"] <- CO2_bulk100
  rhizo100[, "CO2"] <- CO2_rhizo100
  
  ## 2026-08-14 SW: 2sp row duplication removed (nsites <- 1)
  # 30 
  
  # 50
  
  # 70
  
  # 100

  ##END of CORPSE main loop
  
  
  ##Start of FUN model main loop
  # 2026-08-14 SW: with nsites <- 1 this was a one-iteration loop. It is kept as a
  # braced block with a fixed index rather than deleted, so that every [i,j]
  # reference inside is unchanged and every FUN matrix stays 1-column.
  # To restore multiple sites: replace the two lines below with
  #   for (j in 1:nsites) {
  # and nothing else in this block needs to change.
  j <- 1
  {
    ##Update FUN model shared_inorganic N with CORPSE model shared_inorganic N
    # 2026-08-14 SW: was shared_inorganicN[1], a hardcoded site index inside the j block
    FUN_shared_inorganicN[i, j] <- shared_inorganicN[j]
    
    ## Assume passive uptake with transpiration is zero  
    # we're doing this because we don't measure nor predict transpiration
    Npassive[i,j] <- 0
    # set passive uptake to minimum of either Npassive or inorganic N pool
    Npassive[i,j] <- pmin(Npassive[i,j], FUN_shared_inorganicN[i,j]) 
    
    ##Calculate soil N remaining- update N pool after any passive uptake
    rsoilN[i,j] <- FUN_shared_inorganicN[i,j] - Npassive[i,j]
    
    ##Sum passive and storage N allocation 
    free[i,j] <- Npassive[i,j]
    
    ##Calculate the cost for each uptake strategy
    ##N fixation costs
    # If you have one year of soil temp data use k to reference soil T for each DOY
    cost_fix[i,j]<-(s_fix*exp(a_fix+b_fix*soilT[k]*(1-0.5*soilT[k]/c_fix))-2*s_fix)
    # soil T data for each day of the run is referenced with "i"
    # cost_fix[i,j] <- (s_fix * exp(a_fix + b_fix * soilT[i] * (1-0.5 * soilT[i] / c_fix)) - 2 * s_fix)
    
    ##Make the cost of retranslocation high during green season
    cost_resorb[i,j] <- Inf
    
    ##Update FUN model shared_inorganic N with remaining soil N calculated
    FUN_shared_inorganicN[i,j] <- rsoilN[i,j]
    
    ##cost of non mycorrhizal uptake - +inf
    cost_non_myco[i,j] <- (Non_kN / FUN_shared_inorganicN[i,j]) + 
                          (Non_kC / daily_root_bio_juv_sum[i,j])
    
    ##cost of mycorrhizal uptake - +inf
    cost_active[i,j] <- (kN / FUN_shared_inorganicN[i,j]) + 
                        (kC / daily_root_bio_juv_sum[i,j]) 
        
    
    ##Making cost of N storage high after growing season
     
    leafNdaystorage <- 365 
    
    if(leafN[i,1] == 1){ # if it is a last day
      leafNdaystorage <- in_doy[i] # then assign leafNdaystorage to that last day DOY
    }
    
    if(in_doy[i] > leafNdaystorage){ # make cost of storage infinite after last day
      cost_storage[i,j] <- Inf # cost (2.0e-3) filled in the same every day when matrix was made
    }
    
    if(in_doy[i] > 364){ # this resets the leafNdaystorage for each year
      leafNdaystorage <- in_doy[i]
    }
    
    
    ##Making cost of N storage high if storage N is equal to 0
    if (FUNstorageN[i,j] <= 0) {
      cost_storage[i,j] <- Inf
    }
    
    ##Adding in a newer retranslocation function that calculates at an annual scale
    ##and it spreads over the senescence period 
    
    ##Calculate cost of resorption 
    ##leafN is a df w/ same # rows as input & columns 1:4 = 
    ## 1) input$last (0,1),
    ## 2) input$harv (0,1),
    ## 3) input$aglivn (continuous), and 
    ## 4) retranslocatable leaf N pool (continuous)
    leafNday <- 365
    leafN2 <- 0 # initialize a new value
    if (leafN[i,1] == 1) { # if a last day...
      cost_resorb[i,j] <- kR / leafN[i,4] # calculate resorb cost
      leafN2 <- leafN[i,4] # set leafN2 = retranslocatable leaf N pool
      leafNday <- in_doy[i] # set leafNday = doy
    } # Else leafN2 <- 0
    
    ##use resistance network to get integrated cost 
    # this is the summed C cost per unit N uptaken
    rec_cost_acq[i,j] <- (
      (1/cost_active[i,j])
      + (1/cost_fix[i,j])
      + (1/cost_resorb[i,j])
      + (1/cost_non_myco[i,j])
      + (1/cost_storage[i,j])
    )
    
    cost_acq[i,j] <- (1/rec_cost_acq[i,j])
    
    ##This code below simultaneously solves eqs. 6a-6d from Fisher et al. 2010
    ##to optimize C allocated to growth and N uptake. N uptake is truncated if      
    ##Ndemand is met or leaf N pool is exhausted. 
    
    ##Add in storage N demand to pool 
    if (leafN[i,1] == 1) { # if it is a last day...
      Ndemand_plus_storage[i,j] <- totalNdemand[i-1, j] + storageNdemand[i]
      ##Add in storage C into NPP or C available pool
      NPP_plus_storage[i,j] <- NPP[i-1,j] + storageC[i] 
    } else {
      NPP_plus_storage[i,j] <- NPP[i,j]
      Ndemand_plus_storage[i,j] <- totalNdemand[i,j]
    }
    
    Cavailable[i,j] <- NPP_plus_storage[i,j]
    Ndeficit[i,j] <- Ndemand_plus_storage[i,j]
    
    if (Ndeficit[i,j] <= 0) {
      Nacq[i,j] <- 0
      Cacq[i,j] <- 0
      Cgrowth[i,j] <- Cgrowth[i,j]
    }
    
    
    if (Ndeficit[i,j] > 0) {
      Cacq[i,j] <- (Cavailable[i,j] - (free[i,j] * (plantCN[i,j])))/
        (1 + (plantCN[i,j]) / cost_acq[i,j])
      Nacq[i,j] <- pmin(Ndeficit[i,j],(Cacq[i,j] / cost_acq[i,j]))
      Cgrowth[i,j] <- Cavailable[i,j] - (Nacq[i,j] * cost_acq[i,j])
      
      total_Nacq_active[i,j] <- Cacq[i,j] / cost_active[i,j]
      total_Nacq_non_myco[i,j] <- Cacq[i,j] / cost_non_myco[i,j]
      total_Nacq_resorb[i,j] <- Cacq[i,j] / cost_resorb[i,j]
      total_Nacq_fix[i,j] <- Cacq[i,j] / cost_fix[i,j]
      total_Nacq_storage[i,j] <- Cacq[i,j] / cost_storage[i,j]
    }
    
    # 2026-08-14 SW: was total_Nacq_storage[i] <- ... . A single subscript on a matrix
    # is linear indexing, so this always wrote into column 1 regardless of j.
    total_Nacq_storage[i,j] <- pmin(total_Nacq_storage[i,j], FUNstorageN[i,j]) 
    
    total_Nacq[i,j] <- ( 
      total_Nacq_active[i,j]
      + total_Nacq_fix[i,j]
      + total_Nacq_non_myco[i,j]
      + total_Nacq_resorb[i,j]
      + total_Nacq_storage[i,j]
    )
    
    if (total_Nacq[i,j] > Ndeficit[i,j]){
      Nacq_scaler <- Ndeficit[i,j] / total_Nacq[i,j]
      total_Nacq_active[i,j] <- total_Nacq_active[i,j] * Nacq_scaler
      total_Nacq_fix[i,j] <- total_Nacq_fix[i,j] * Nacq_scaler
      total_Nacq_non_myco[i,j] <- total_Nacq_non_myco[i,j] * Nacq_scaler
      total_Nacq_resorb[i,j] <- total_Nacq_resorb[i,j] * Nacq_scaler
      total_Nacq_storage[i,j] <- total_Nacq_storage[i,j] * Nacq_scaler
    }
    
    ##Truncate resorb if exceeds leaf N
    if (total_Nacq_resorb[i,j] > leafN2) { # should be day before harvest
      total_Nacq_resorb[i,j] <- leafN2
      Cgrowth[i,j] <- Cavailable[i,j] - (Nacq[i,j] * cost_acq[i,j])
    }
    
    ##Update Storage N pool to include retranslocation
    if (leafN[i,1] == 0) { #  if not a last day...
      FUNstorageN[i+1,j] <- FUNstorageN[i,j] - total_Nacq_storage[i,j]
    } 
    
    if(FUNstorageN[i+1,j] < 0){
      FUNstorageN[i+1,j] <- 0
    }
    
    if (leafN[i,1] == 1) { # if a last day...
      total_Nacq_active[i,j] <- 0
      total_Nacq_fix[i,j] <- 0
      total_Nacq_non_myco[i,j] <- 0
      FUNstorageN[i+1,j] <- (
        FUNstorageN[i,j]
        + total_Nacq_resorb[i,j]
        + total_Nacq_active[i,j]
        + total_Nacq_non_myco[i,j]
        + total_Nacq_fix[i,j]  
      )
    }
    
    if (in_doy[i] > leafNday) { # harvest date #
      FUNstorageN[i+1,j] <- FUNstorageN[i,j] - total_Nacq_storage[i,j]
    } 
    
    if (leafN[i,1] == 1){ 
      resorbper[j] <- (1 - (total_Nacq_resorb[i,j] / leafN2))
      # 2026-08-14 SW: was leafN[i,j]. leafN has 4 columns (last, harv, aglivn,
      # retranslocatable), so column j indexed a 0/1 flag rather than an N
      # pool. Column 4 is the retranslocatable pool. Export-only variable.
      litter_productionN[i,j] <- (leafN[i,4] * resorbper[j])
      litter_productionCN[i,j] <- litter_production_c[i] / litter_production_n[i]
    }
    
    total_soil_N_uptake[i,j] <- total_Nacq_active[i,j] + total_Nacq_non_myco[i,j]
    
    ##Scale FUN inorganic N based on N uptake calculated by FUN
    if(total_soil_N_uptake[i,j] > FUN_shared_inorganicN[i,j]) {
      N_uptakescaler[i,j] <- FUN_shared_inorganicN[i,j] / total_soil_N_uptake[i,j]
      total_Nacq_active[i,j] <- total_Nacq_active[i,j] * N_uptakescaler[i,j]
      total_Nacq_non_myco[i,j] <- total_Nacq_non_myco[i,j] * N_uptakescaler[i,j]
      total_soil_N_uptake[i,j] <- FUN_shared_inorganicN[i,j]
    } else {
      N_uptakescaler[i,j] <- 0 # this should be a 1 so it doesn't get scaled (1/9/2022, JR)
    }
    
    total_Nacq[i,j] <- (
      total_Nacq_active[i,j]
      + total_Nacq_fix[i,j]
      + total_Nacq_non_myco[i,j]
      + total_Nacq_resorb[i,j]
      + total_Nacq_storage[i,j]
    )
    
  }
  
  # check if shared_inorganicN is balanced across the depth profile
  sum_shared_inorganicN <- shared_inorganicN30 + shared_inorganicN50 + shared_inorganicN70 + shared_inorganicN100
  
  if( FUN_shared_inorganicN[ i , 1] != sum_shared_inorganicN[1] ) {crash('FUN_shared_inorganicN is unbalanced')}
  
  if( shared_inorganicN[ 1 ] != sum_shared_inorganicN[1] ) {crash('shared_inorganicN is unbalanced')}
  
  ##Update Corpse model shared_inorganic N pool with FUN inorganic N pool
  # using the fraction of inorganicN in each depth layer to scale the size of the updated pool
  
  # 2026-08-14 SW: guard added. If the whole profile reaches zero inorganic N these
  # four fractions become NaN, which propagates silently into all four
  # shared_inorganicN pools and only surfaces on the NEXT timestep as
  # "missing value where TRUE/FALSE needed" from a min() guard.
  if ( any( sum_shared_inorganicN <= 0 ) ) {crash('profile inorganic N is zero or negative')}
  
  fracN30 <- ( shared_inorganicN30 / ( sum_shared_inorganicN ) )[ 1 ]
  
  fracN50 <- ( shared_inorganicN50 / ( sum_shared_inorganicN ) )[ 1 ]
  
  fracN70 <- ( shared_inorganicN70 / ( sum_shared_inorganicN ) )[ 1 ]
  
  fracN100 <- ( shared_inorganicN100 / ( sum_shared_inorganicN ) )[ 1 ]
  
  # and then, shared_inorganicN30 <- FUN_shared_inorganicN30[i,] - total_soil_N_uptake30[i,]
  
  shared_inorganicN30 <- fracN30 * ( FUN_shared_inorganicN[i,] - total_soil_N_uptake[i,] )
  
  shared_inorganicN50 <- fracN50 * ( FUN_shared_inorganicN[i,] - total_soil_N_uptake[i,] )
  
  shared_inorganicN70 <- fracN70 * ( FUN_shared_inorganicN[i,] - total_soil_N_uptake[i,] )
  
  shared_inorganicN100 <- fracN100 * ( FUN_shared_inorganicN[i,] - total_soil_N_uptake[i,] )
  
  ##Calculate fungal production and rhizosphere C flux to be input into CORPSE model
  
  # add fungal production and rhizoC flux to multiple depths
  if(i<timestep){
    fungal_prod[i+1,] <- total_Nacq_active[i,]*cost_acq[i,] 
    rhizoC_flux[i+1,] <- total_Nacq_non_myco[i,]*cost_acq[i,]
  }
  
  ##end of FUN model main loop
  
 
}

end.time <- Sys.time()
time.taken <- end.time - start.time

cat( paste0( 
  "\n\n" ,
  "spinup successfully completed!" ,
  "\n" ,
  round( as.numeric( difftime( end.time , start.time , units = "secs") ) , 2 ) , " seconds to spin up\n" , 
  nyears , " years\n" ,
  round( as.numeric( difftime( end.time , start.time , units = "secs") )  / nyears , 2 ) , " seconds per year"
  ) ,
     file = file.path( "experimental_models" , paste0( proj_name ) , paste0( proj_name , ".md" ) ) ,
     append = TRUE )


# prepare export ----

### CORPSE data to export

# Combine daily data saved in lists into dataframe for each soil layer
# 30 
# 2026-08-14 SW MATRIX: the recorded lists hold matrices, so rbind returns a matrix.
# One conversion to data.frame here leaves every downstream dplyr / mutate /
# export step below identical to the non-matrix version.
bulk30_final <- as.data.frame( do.call( rbind , bulk30_final_list ) )
rhizo30_final <- as.data.frame( do.call( rbind , rhizo30_final_list ) )
litter30_final <- as.data.frame( do.call( rbind , litter30_final_list ) )
bulk30_till_final <- as.data.frame( do.call( rbind , bulk30_till_final_list ) )
rhizo30_till_final <- as.data.frame( do.call( rbind , rhizo30_till_final_list ) )

# 50 
bulk50_final <- as.data.frame( do.call( rbind , bulk50_final_list ) )
rhizo50_final <- as.data.frame( do.call( rbind , rhizo50_final_list ) )

# 70 
bulk70_final <- as.data.frame( do.call( rbind , bulk70_final_list ) )
rhizo70_final <- as.data.frame( do.call( rbind , rhizo70_final_list ) )

# 100
bulk100_final <- as.data.frame( do.call( rbind , bulk100_final_list ) )
rhizo100_final <- as.data.frame( do.call( rbind , rhizo100_final_list ) )


# 2sp - subset every other row of layers output data for export
bulk30_final_export <- bulk30_final
rhizo30_final_export <- rhizo30_final
litter30_final_export <- litter30_final
bulk30_till_final_export <- bulk30_till_final
rhizo30_till_final_export <- rhizo30_till_final

# 50
bulk50_final_export <- bulk50_final
rhizo50_final_export <- rhizo50_final

# 70
bulk70_final_export <- bulk70_final
rhizo70_final_export <- rhizo70_final

# 100
bulk100_final_export <- bulk100_final
rhizo100_final_export <- rhizo100_final

# add values for each soil layer depth together to get total values for each depth
final_30_export <- 
  (bulk30_final_export + 
  rhizo30_final_export + 
  litter30_final_export +
  bulk30_till_final_export +
  rhizo30_till_final_export )

# 50
final_50_export <- 
  (bulk50_final_export + 
  rhizo50_final_export )

# 70
final_70_export <- 
  (bulk70_final_export + 
     rhizo70_final_export )

# 100
final_100_export <- 
  ( bulk100_final_export + 
    rhizo100_final_export )


##Add values from soil layers together to calculate total soil values
final_total_export <- 
    ( final_30_export + 
      final_50_export + 
      final_70_export + 
      final_100_export ) 


##Calculate total soil carbon and total soil nitrogen
# start with columns of different SOM types for whole soil

totals <-
  final_total_export %>% 
  mutate(       
    tc = rowSums( across( c( uFastC , uSlowC , uNecroC , pFastC , 
                                      pSlowC , pNecroC , livingMicrobeC ) ) )  ,
    tn = rowSums( across( c( uFastN , uSlowN , uNecroN , pFastN , 
                                      pSlowN , pNecroN , livingMicrobeN ) ) ),
    pctc = ( tc / tc[1] ) * 100 ,
    pctn = ( tn / tn[1] ) * 100 ) 



# Prepare data frame of protected to unprotected SOC ratios
protection_ratios <-
  data.frame(
    yr = input$yr,
    doy = input$doy )  %>%
  mutate( whole_soil_ratio_across_depths = ( final_total_export$pFastC+final_total_export$pSlowC+final_total_export$pNecroC)/ (final_total_export$uFastC+final_total_export$uSlowC+final_total_export$uNecroC ) ,
         
          tilled30_ratio = ( rhizo30_till_final_export$pFastC + rhizo30_till_final_export$pSlowC + rhizo30_till_final_export$pNecroC + bulk30_till_final_export$pFastC + bulk30_till_final_export$pSlowC + bulk30_till_final_export$pNecroC) / (bulk30_till_final_export$uFastC + bulk30_till_final_export$uSlowC + bulk30_till_final_export$uNecroC + rhizo30_till_final_export$uFastC + rhizo30_till_final_export$uSlowC + rhizo30_till_final_export$uNecroC ),
         
          untilled30_ratio = ( rhizo30_final_export$pFastC + rhizo30_final_export$pSlowC + rhizo30_final_export$pNecroC + bulk30_final_export$pFastC + bulk30_final_export$pSlowC + bulk30_final_export$pNecroC )/( bulk30_final_export$uFastC + bulk30_final_export$uSlowC + bulk30_final_export$uNecroC + rhizo30_final_export$uFastC + rhizo30_final_export$uSlowC + rhizo30_final_export$uNecroC ) ,
          # whole soil 30
          whole_soil30_ratio = ( final_30_export$pFastC+final_30_export$pSlowC+final_30_export$pNecroC)/ (final_30_export$uFastC+final_30_export$uSlowC+final_30_export$uNecroC ) ,
          # whole soil 50
          whole_soil50_ratio = ( final_50_export$pFastC+final_50_export$pSlowC+final_50_export$pNecroC)/ (final_50_export$uFastC+final_50_export$uSlowC+final_50_export$uNecroC ) ,
          # whole soil 70
          whole_soil70_ratio = ( final_70_export$pFastC+final_70_export$pSlowC+final_70_export$pNecroC)/ (final_70_export$uFastC+final_70_export$uSlowC+final_70_export$uNecroC ) ,
          # whole soil 100
          whole_soil100_ratio = ( final_100_export$pFastC+final_100_export$pSlowC+final_100_export$pNecroC)/ (final_100_export$uFastC+final_100_export$uSlowC+final_100_export$uNecroC )  
          )


### FUN data to export

# Make a data frame of C spent and N acquired from each pathway, 
# then calculate total N acquired/C spent, root facilitated N acquired/C spent
FUN_CN <- 
  data.frame("NPP" = NPP[,1],
             
             "cost_acq" = cost_acq[,1],
             "cost_fix" = cost_fix[,1],
             "cost_active" = cost_active[,1],
             "cost_non_myco" = cost_non_myco[,1],
             "cost_resorb" = cost_resorb[,1],
             "cost_storage" = cost_storage[,1],
             
             "Nacq_Total" = total_Nacq[,1],
             "Nacq_Fix" = total_Nacq_fix[, 1],
             "Nacq_zActive" = total_Nacq_active[, 1],
             "Nacq_Non_myco" = total_Nacq_non_myco[, 1],
             "Nacq_Resorb" = total_Nacq_resorb[, 1],
             "Nacq_Storage" = total_Nacq_storage[, 1]) %>%
  mutate(Nacq_rootFacilitated = Nacq_zActive + Nacq_Non_myco, 
         
         Cspent_Total = Nacq_Total*cost_acq,
         Cspent_zActive = Nacq_zActive*cost_acq, 
         Cspent_Fix = Nacq_Fix*cost_acq, 
         Cspent_Non_myco = Nacq_Non_myco*cost_acq, 
         Cspent_Resorb = Nacq_Resorb*cost_acq,
         Cspent_Storage = Nacq_Storage*cost_acq, 
         Cspent_rootFacilitated = (Nacq_zActive + Nacq_Non_myco)*cost_acq)

# bind all FUN Matrices together in one data table for export
FUN_Matrices <- 
  data.frame("Cacq" = Cacq[,1],
             "Cavailable" = Cavailable[,1],
             "Cgrowth" = Cgrowth[,1],
             "cost_acq" = cost_acq[,1],
             "cost_active" = cost_active[,1],
             "cost_fix" = cost_fix[,1],
             "cost_non_myco" = cost_non_myco[,1],
             "cost_resorb" = cost_resorb[,1],
             "cost_storage" = cost_storage[,1],
             "free" = free[,1],
             "FUN_shared_inorganicN" = FUN_shared_inorganicN[,1],
             "FUNstorageN" = FUNstorageN[1:nrow(input),1], # one extra datapoint? 
             "leafNdemand" = leafNdemand[,1],
             "litter_productionCN" = litter_productionCN[,1],
             "litter_productionN" = litter_productionN[,1],
             "N_uptakescaler" = N_uptakescaler[,1],
             "Nacq" = Nacq[,1],
             "Ndeficit" = Ndeficit[,1],
             "Ndemand_plus_storage" = Ndemand_plus_storage[,1],
             "Npassive" = Npassive[,1],
             "NPP_plus_storage" = NPP_plus_storage[,1],
             "plantCN" = plantCN[,1],
             "rec_cost_acq" = rec_cost_acq[,1],
             "resorbper" = resorbper[,1],
             "rootNdemand" = rootNdemand[,1],
             "rsoilN" = rsoilN[,1],
             "storageNmob" = storageNmob[,1],
             "total_Cgrowth" = total_Cgrowth[,1],
             "total_Nacq" = total_Nacq[,1],
             "total_Nacq_active" = total_Nacq_active[,1],
             "total_Nacq_fix" = total_Nacq_fix[,1],
             "total_Nacq_non_myco" = total_Nacq_non_myco[,1],
             "total_Nacq_resorb" = total_Nacq_resorb[,1],
             "total_Nacq_storage" = total_Nacq_storage[,1],
             "total_soil_N_uptake" = total_soil_N_uptake[,1],
             "totalNdemand" = totalNdemand[,1],
             
             "rhizoC_flux" = rhizoC_flux[,1],
             "fungal_prod" = fungal_prod[,1]
  )

FUN_stuff <- cbind( yr = input$yr , doy = input$doy , FUN_CN )  %>% left_join( FUN_Matrices ) 

### One datatable with all export data needed for data analysis
# add necessary data onto input data file

# why is this not working?
count( totals ) - count( protection_ratios ) 
count( final_total_export ) - count( input )

names( input )
names( totals )

data_export <- 
  cbind( input , totals ) %>% # individual and total C and N pools
  mutate(
    whole_soil_ratio_across_depths = protection_ratios$whole_soil_ratio_across_depths,
    tilled_ratio = protection_ratios$tilled30_ratio,
    untilled_ratio = protection_ratios$untilled30_ratio,
    whole_soil30_ratio = protection_ratios$whole_soil30_ratio ,
    whole_soil50_ratio = protection_ratios$whole_soil50_ratio ,
    whole_soil70_ratio = protection_ratios$whole_soil70_ratio ,
    whole_soil100_ratio = protection_ratios$whole_soil100_ratio ,

    fungal_prod = FUN_Matrices$fungal_prod,
    rhizoC_flux = FUN_Matrices$rhizoC_flux,
   
    litter_production_c = litter_production_c
   )

# exporting the parameters used in the run across all depths

params_export_fun <- 
  function( dtf , label , label2 ){  
    data.frame( Value = t( dtf  ) ) %>% 
      tibble::rownames_to_column("Param" ) %>% 
      mutate( Cat = paste( label ) ) %>% 
      rbind(
        data.frame(
          "pct_soil_tilled" = pct_soil_tilled, 
          "tillPtoUP" = tillPtoUP,
          "porosity" = porosity,
          "storageCN" = storageCN,
          "exudate_CN" = exudate_CN,
          "cost_param_mult" = cost_param_mult,
          "a_fix" = a_fix,
          "b_fix" = b_fix,
          "c_fix" = c_fix,
          "s_fix" = s_fix,
          "kR" = kR, 
          "Non_kN" = Non_kN, 
          "Non_kC" = Non_kC, 
          "kC" = kC,
          "kN" = kN, 
          "claymod" = claymod,  
          "exudate_Cinput" = exudate_Cinput,
          "exudate_Ninput" = exudate_Ninput,
          "inorg_Ndep" = inorg_Ndep) %>% 
          t() %>% 
          data.frame() %>% 
          tibble::rownames_to_column("Param") %>% 
          dplyr::rename("Value" = ".") %>% 
          mutate(Cat = paste( label2 ))
      ) %>% 
      format(scientific = FALSE) %>% 
      relocate(Cat, .before = Param)
    
  }

# parameters for depth interval 0-30
params_30 <- 
  params_export_fun( params , "params_30" , "Other_30" ) %>% 
  # these are the litter parameters, also in topsoil
  rbind(
    data.frame(Value = t( params_litter )) %>% 
      tibble::rownames_to_column("Param") %>% 
      mutate(Cat = "params_litter"))

# parameters for depth interval 30-50
params_50 <- 
  params_export_fun( params , "params_50" , "Other_50")


# parameters for depth interval 50-70
params_70 <- 
  params_export_fun( params , "params_70", "Other_70" )

# parameters for depth interval 70-100
params_100 <- 
  params_export_fun( params , "params_100" , "Other_100" )


params_export <- 
  rbind( params_30 , params_50 ) %>% 
  rbind( params_70 ) %>% 
  rbind( params_100)

# summarise main results

last <- 
  final_total_export %>% 
  tail( 1 ) %>% 
  pivot_longer( cols = everything() ) %>% 
  mutate( value = round( value , 4 )) 

captured_text <- capture.output( write.table( last , row.names = FALSE  ) ) 


cat( 
  "\n" ,
  paste0("Results are in kg C/m2, last values" ) ,
  "\n" ,
  paste0( captured_text[ -1]  ) ,
  file = file.path( "experimental_models" , paste0( proj_name ) , paste0( proj_name , ".md" ) ) ,
  append = TRUE )

# export data  ----

c_expend_per_depth <-
  as.data.frame(
    cbind( yr = input$yr , doy = input$doy ,
           fungal_prod_per_depth ,
           root_exude_per_depth ,
           root_turnover_per_depth ) )

export( c_expend_per_depth )

# export years and doy for each row
yr_doy <- cbind( input$yr ,  input$doy )
export( yr_doy )

## export the data table with the parameter values used in the run
export( params_export )

## export data_export data frame with all data for analysis
export( data_export )

### Export FUN DataSets
# FUN C and N output

export( FUN_stuff )

# compartment & depth
export( bulk30_final_export )
export( rhizo30_final_export )
export( litter30_final_export )
export( bulk30_till_final_export  )
export( rhizo30_till_final_export   )

export( bulk50_final_export  )
export( rhizo50_final_export  )

export( bulk70_final_export  )
export( rhizo70_final_export  )

export( bulk100_final_export  )
export( rhizo100_final_export  )

# depth
export( final_30_export  )

export( final_50_export  )

export( final_70_export  )

export( final_100_export  )

# total
export( final_total_export  )

# write int_vals for the next stage ----
# 2026-08-14 SW STAGE: the last row of each pool time series is written out in the
# layout the next stage expects, so staging the next run is a file copy rather
# than a manual reconstruction. Written into this run's own output folder;
# copy them into 02_bioenergy/int_vals/ when ready.

int_vals_out <- file.path( "experimental_models" , proj_name , "int_vals_for_next_stage" )
dir.create( int_vals_out , showWarnings = FALSE )

for ( .p in c( "bulk30","rhizo30","bulk30_till","rhizo30_till","litter30",
               "bulk50","rhizo50","bulk70","rhizo70","bulk100","rhizo100" ) ) {
  .obj <- get( paste0( .p , "_final_export" ) )
  write.csv( .obj[ nrow( .obj ) , , drop = FALSE ] ,
             file.path( int_vals_out , paste0( .p , "_int.csv" ) ) ,
             row.names = FALSE )
}
rm( .p , .obj )

cat( paste0( proj_name , "\n" ) ,
     file = file.path( int_vals_out , "which_run_produced_these.txt" ) )

# compare to benchmark ----

# ! fix the code in the compare_spinup_to_benchmark.R
# this outputs a comparison figure in the relevant 
source( "~/Dropbox/WVU_postdoc/projects/weber_deep_fbc/compare_spinup_to_benchmark_me.R" )

# script finished -----
# 
# system("zenity --error --text='Script complete'") 

